/*
Programmer name: Sarah Carley
Date made: 1/28/23
Date last modified: 1/29/23
Description: This is where structs/nodes will be initialized, libraries included, and functions declared
*/

#ifndef MUSIC_H
#define MUSIC_H

#define _CRT_SECURE_NO_WARNINGS

#include<stdio.h>
#include<string.h>
#include<stdlib.h>

typedef struct duration
{
	int minutes;
	int seconds;
}Duration;

typedef struct record
{
	char artist[30];
	char album_title[30];
	char song_title[30];
	char genre[30];
	Duration song_length;
	int times_played;
	int rating;
}Record;


typedef struct node
{
	Record data;
	struct node* pNext;
	struct node* pPrev;
}Node;


/*
 Function: get_menu_choice()
 Date Created: 1/28/23
 Date Last Modified: 1/28/23
 Description: This prints off the menu for the user and gets their choice
 Input parameters: none
 Returns: the user's choice
 Preconditions: none
 Postconditions: the choice must be returned
*/
int get_menu_choice(void);

/*
 Function: make_node()
 Date Created: 1/28/23
 Date Last Modified: 1/28/23
 Description: This creates a new node from the existing data
 Input parameters: the data
 Returns: the node
 Preconditions: none
 Postconditions: the node must be returned
*/
Node* make_node(Record new_data);

/*
 Function: insert_at_front()
 Date Created: 1/28/23
 Date Last Modified: 1/28/23
 Description: This adds the new node to the front of the linked list
 Input parameters: the data, the double pointer to the first value in the list
 Returns: if it was successful
 Preconditions: the data must exist
 Postconditions: the success must be returned
*/
int insert_at_front(Node** pList, Record new_data);

/*
 Function: print_all()
 Date Created: 1/28/23
 Date Last Modified: 1/28/23
 Description: This prints the songs in the entire linked list, starting at the head
 Input parameters: the pointer to the linked list
 Returns: nothing
 Preconditions: the list must exist
 Postconditions: the data must be printed
*/
void print_all(Node* pList);

/*
 Function: choose_artist()
 Date Created: 1/29/23
 Date Last Modified: 1/30/23
 Description: This gets the user to choose an artist from all artists from the list
 Input parameters: the pointer to the linked list, the pointer to the artist choice
 Returns: nothing
 Preconditions: the list must exist
 Postconditions: the atist choice must be updated
*/
void choose_artist(Node* pList, char* artist_choice);

/*
 Function: print_artist()
 Date Created: 1/29/23
 Date Last Modified: 1/30/23
 Description: This prints all songs from the artist
 Input parameters: the pointer to the linked list, the pointer to the artist choice
 Returns: the number of loops
 Preconditions: the list must exist, the artist choice must exist
 Postconditions: the songs related to the artist must be printed
*/
int print_artist(Node* pList, char* artist_choice);

/*
 Function: edit_song()
 Date Created: 1/30/23
 Date Last Modified: 1/30/23
 Description: This allows the user to edit the values in a node to change the song's data
 Input parameters: the double pointer to the linked list, the pointer to the artist choice
 Returns: nothing
 Preconditions: the list must exist, the artist choice must exist
 Postconditions: the nodes must be updated
*/
void edit_song(Node** pList, char* artist_choice);

/*
 Function: edit_rating()
 Date Created: 1/30/23
 Date Last Modified: 1/30/23
 Description: This allows the user to edit the rating in the data for the record
 Input parameters: the double pointer to the linked list, the pointer to the artist choice
 Returns: nothing
 Preconditions: the list must exist, the artist choice must exist
 Postconditions: the rating must be updated
*/
void edit_rating(Node** pList, char* artist_choice);

/*
 Function: choose_song()
 Date Created: 1/30/23
 Date Last Modified: 1/30/23
 Description: This allows the user to choose the song
 Input parameters: the  pointer to the linked list, the pointer to the song choice
 Returns: nothing
 Preconditions: the list must exist
 Postconditions: the song choice must be updated
*/
void choose_song(Node* pList, char* song_choice);

/*
 Function: play_songs()
 Date Created: 1/30/23
 Date Last Modified: 1/30/23
 Description: This allows the user to play the songs, starting at the one they chose to start on
 Input parameters: the  pointer to the linked list, the pointer to the song choice
 Returns: nothing
 Preconditions: the list must exist, the song choice must also exist
 Postconditions: the songs starting at the one chosen must "play" in order
*/
void play_songs(Node* pList, char* song_choice);





#endif