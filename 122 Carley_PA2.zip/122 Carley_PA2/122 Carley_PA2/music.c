/*
Programmer name: Sarah Carley
Date made: 1/28/23
Date last modified: 1/29/23
Description: This is where functions will be made for the main program
*/

#include "music.h"

/*
 Function: get_menu_choice()
 Date Created: 1/28/23
 Date Last Modified: 1/28/23
 Description: This prints off the menu for the user and gets their choice
 Input parameters: none
 Returns: the user's choice
 Preconditions: none
 Postconditions: the choice must be returned
*/
int get_menu_choice(void)
{
	//gets the user's choice, loops while it is not valid
	int choice = 0;
	do
	{
		printf("Welcome to the music manager!\n1: load\n2: store\n3: display\n4: insert\n5: delete\n6: edit\n7: sort\n8: rate\n9: play\n10: shuffle\n11: exit\n");
		scanf("%d", &choice);
	} while (choice < 1 || choice > 11);
	return choice;
}


/*
 Function: make_node()
 Date Created: 1/28/23
 Date Last Modified: 1/28/23
 Description: This creates a new node from the existing data
 Input parameters: the data
 Returns: the node
 Preconditions: none
 Postconditions: the node must be returned
*/
Node* make_node(Record new_data)
{
	//creates a mem pointer
	Node* mem_ptr = malloc(sizeof(Node));
	char line[100] = "";
	if (mem_ptr != NULL)
	{
		//Parses the data onto the node
		strcpy(mem_ptr->data.artist, new_data.artist);
		strcpy(mem_ptr->data.album_title, new_data.album_title);
		strcpy(mem_ptr->data.song_title, new_data.song_title);
		strcpy(mem_ptr->data.genre, new_data.genre);
		mem_ptr->data.song_length.minutes = new_data.song_length.minutes;
		mem_ptr->data.song_length.seconds = new_data.song_length.seconds;
		mem_ptr->data.times_played = new_data.times_played;
		mem_ptr->data.rating = new_data.rating;

		mem_ptr->pNext = NULL;
	}
	return mem_ptr;
}


/*
 Function: insert_at_front()
 Date Created: 1/28/23
 Date Last Modified: 1/28/23
 Description: This adds the new node to the front of the linked list
 Input parameters: the data, the double pointer to the first value in the list
 Returns: if it was successful
 Preconditions: the data must exist
 Postconditions: the success must be returned
*/
int insert_at_front(Node** pList, Record new_data)
{
	Node* mem_ptr = make_node(new_data);
	int success = 0;
	if (mem_ptr != NULL)
	{
		success = 1;
		//Makes it point to the first item in the list as the pNext
		mem_ptr->pNext = *pList;
		//sets pPrev to NULL
		mem_ptr->pPrev = NULL;
		//if the list isn't NULL
		if ((*pList) != NULL)
		{
			//The next node's pPrev points at mem_ptr
			(*pList)->pPrev = mem_ptr;
		}
		//updates the front of the list
		*pList = mem_ptr;
	}
	return success;
}

/*
 Function: print_all()
 Date Created: 1/28/23
 Date Last Modified: 1/28/23
 Description: This prints the songs in the entire linked list, starting at the head
 Input parameters: the pointer to the linked list
 Returns: nothing
 Preconditions: the list must exist
 Postconditions: the data must be printed
*/
void print_all(Node* pList)
{
	Node* cur = pList;
	while (cur != NULL)
	{
		//prints all the values of the node
		printf("%s, %s, %s, %s, %d:%d, %d, %d\n", cur->data.artist, cur->data.album_title, cur->data.song_title,
			cur->data.genre, cur->data.song_length.minutes, cur->data.song_length.seconds, cur->data.times_played, cur->data.rating);
		cur = cur->pNext;
	}
}


/*
 Function: choose_artist()
 Date Created: 1/29/23
 Date Last Modified: 1/30/23
 Description: This gets the user to choose an artist from all artists from the list
 Input parameters: the pointer to the linked list, the pointer to the artist choice
 Returns: nothing
 Preconditions: the list must exist
 Postconditions: the atist choice must be updated
*/
void choose_artist(Node* pList, char* artist_choice)
{
	Node* cur = pList;
	int choices[20], index = 0, index2 = 1, char_index = 0, copy = 0, choice = 0, success = 0;
	char artist[20][30] = {""};

	while (cur != NULL)
	{
		index2 = 1;
		copy = 0;

		char_index = 0;
		//finds the artist
		strcpy(artist[index], cur->data.artist);


		while (index2 <= index)
		{
			//shows that there is another artist with the same name
			if (strcmp(artist[index - index2], cur->data.artist) == 0)
			{
				copy = 1;
			}
			index2++;
		}
		if (copy != 1)
		{
			//if there is not a copy the index is changed
			index++;
		}
		//the cur pointer is brought to the next node in the linked list
		cur = cur->pNext;
	}
	

	do
	{
		index2 = 0;
		//prompts the user to choose an artist
		printf("Choose an artist: \n");
		while (index2 < index)
		{
			//prints the artists
			printf("%d: %s\n", index2 + 1, artist[index2]);
			index2++;
		}
		scanf("%d", &choice);
	} while(choice < 1 || choice > index + 1);
	//changes the artist_choice to the artist the user chose
	strcpy(artist_choice, artist[choice - 1]);
}


/*
 Function: print_artist()
 Date Created: 1/29/23
 Date Last Modified: 1/30/23
 Description: This prints all songs from the artist
 Input parameters: the pointer to the linked list, the pointer to the artist choice
 Returns: the number of loops
 Preconditions: the list must exist, the artist choice must exist
 Postconditions: the songs related to the artist must be printed
*/
int print_artist(Node* pList, char* artist_choice)
{
	Node* cur = pList;
	int loops = 0;
	while (cur != NULL)
	{
		if (strcmp(cur->data.artist, artist_choice) == 0)
		{
			//Prints the data from the artist
			loops++;
			printf("%d: %s, %s, %s, %s, %d:%d, %d, %d\n", loops, cur->data.artist, cur->data.album_title, cur->data.song_title,
				cur->data.genre, cur->data.song_length.minutes, cur->data.song_length.seconds, cur->data.times_played, cur->data.rating);
		}
		cur = cur->pNext;
	}
	return loops;
}

/*
 Function: edit_song()
 Date Created: 1/30/23
 Date Last Modified: 1/30/23
 Description: This allows the user to edit the values in a node to change the song's data
 Input parameters: the double pointer to the linked list, the pointer to the artist choice
 Returns: nothing
 Preconditions: the list must exist, the artist choice must exist
 Postconditions: the nodes must be updated
*/
void edit_song(Node** pList, char* artist_choice)
{
	Node* cur = *pList;
	int loops = 0, choice = 0, edit_choice = 0, int_input = 0;
	char string_input[30] = "";
	Record songs[20];
	while (cur != NULL)
	{
		if (strcmp(cur->data.artist, artist_choice) == 0)
		{
			//sets songs index of song title to the current song title
			strcpy(songs[loops].song_title, cur->data.song_title);

			//prints the data from the artist
			loops++;
			printf("%d: %s, %s, %s, %s, %d:%d, %d, %d\n", loops, cur->data.artist, cur->data.album_title, cur->data.song_title,
				cur->data.genre, cur->data.song_length.minutes, cur->data.song_length.seconds, cur->data.times_played, cur->data.rating);
		}
		cur = cur->pNext;
	}
	choice = 0;

	//resets cur
	cur = *pList;

	if (loops > 1)
	{
		//gets the user input for which song (if there are multiple from the same artist)
		do
		{
			scanf("%d", &choice);
			choice--;
		} while (choice < 0 || choice > loops - 1);
	}

	if (cur != NULL)
	{
		while (strcmp(songs[choice].song_title, cur->data.song_title) != 0)
		{
			//finds the point in cur where the song title is the same
			if (strcmp(songs[choice].song_title, cur->data.song_title) != 0)
			{
				cur = cur->pNext;
			}
		}

		while (strcmp((*pList)->data.song_title, cur->data.song_title) != 0)
		{
			//finds the point in the list where the song title is the same
			if (strcmp((*pList)->data.song_title, songs[choice].song_title) != 0)
			{
				(*pList) = (*pList)->pNext;
			}
		}
	}
	
	
	while (edit_choice != 8)
	{
		do
		{
			printf("Which would you like to edit?\n1: artist\n2: album\n3: song\n4: genre\n5: minutes\n6: seconds\n7: times played\n8: stop editing\n");
			scanf("%d", &edit_choice);
		} while (edit_choice < 1 || edit_choice > 8);

		if (edit_choice == 1)
		{
			//updates artist name
			printf("Enter new artist name:\n");
			scanf("%s", &string_input);
			strcpy(cur->data.artist, string_input);
		}
		else if (edit_choice == 2)
		{
			//updates album name
			printf("Enter new album name:\n");
			scanf("%s", &string_input);
			strcpy(cur->data.album_title, string_input);
		}
		else if (edit_choice == 3)
		{
			//updates song name
			printf("Enter new song name:\n");
			scanf("%s", &string_input);
			strcpy(cur->data.song_title, string_input);
		}
		else if (edit_choice == 4)
		{
			//updates genre
			printf("Enter new genre:\n");
			scanf("%s", &string_input);
			strcpy(cur->data.genre, string_input);
		}
		else if (edit_choice == 5)
		{
			//updates minute
			printf("Enter new minute:\n");
			scanf("%d", &int_input);
			cur->data.song_length.minutes = int_input;
		}
		else if (edit_choice == 6)
		{
			//updates seconds
			printf("Enter new seconds:\n");
			scanf("%d", &int_input);
			cur->data.song_length.seconds = int_input;
		}
		else if (edit_choice == 7)
		{
			//updates times played
			printf("Enter new times played:\n");
			scanf("%d", &int_input);
			cur->data.times_played = int_input;
		}
		//since ther is an entire option in main for updating the rating, it would be odd to do it here
	}
	
	//changes where everything is pointed
	cur->pNext = (*pList)->pNext;
	cur->pPrev = (*pList)->pPrev;
	//updates the linked list to have the new data
	*pList = cur;


	while ((*pList)->pPrev != NULL)
	{
		//goes back to the front of the list
		(*pList) = (*pList)->pPrev;
	}
}


/*
 Function: edit_rating()
 Date Created: 1/30/23
 Date Last Modified: 1/30/23
 Description: This allows the user to edit the rating in the data for the record
 Input parameters: the double pointer to the linked list, the pointer to the artist choice
 Returns: nothing
 Preconditions: the list must exist, the artist choice must exist
 Postconditions: the rating must be updated
*/
void edit_rating(Node** pList, char* artist_choice)
{
	Node* cur = *pList;
	int loops = 0, choice = 0, edit_choice = 0, int_input = 0;
	Record songs[20];
	while (cur != NULL)
	{
		if (strcmp(cur->data.artist, artist_choice) == 0)
		{
			//sets songs index of song title to the current song title
			strcpy(songs[loops].song_title, cur->data.song_title);

			//prints the data from the artist
			loops++;
			printf("%d: %s, %s, %s, %s, %d:%d, %d, %d\n", loops, cur->data.artist, cur->data.album_title, cur->data.song_title,
				cur->data.genre, cur->data.song_length.minutes, cur->data.song_length.seconds, cur->data.times_played, cur->data.rating);
		}
		cur = cur->pNext;
	}
	choice = 0;

	cur = *pList;

	if (loops > 1)
	{
		do
		{
			//gets user input
			scanf("%d", &choice);
			choice--;
		} while (choice < 0 || choice > loops - 1);
	}


	if (cur != NULL)
	{
		while (strcmp(songs[choice].song_title, cur->data.song_title) != 0)
		{
			//finds the song in the list
			if (strcmp(songs[choice].song_title, cur->data.song_title) != 0)
			{
				cur = cur->pNext;
			}
		}

		while (strcmp((*pList)->data.song_title, cur->data.song_title) != 0)
		{
			//finds the song in the list
			if (strcmp((*pList)->data.song_title, songs[choice].song_title) != 0)
			{
				(*pList) = (*pList)->pNext;
			}
		}
	}


	do
	{
		//asks for new rating
		printf("What rating from 1-5 would you like to give?\n");
		scanf("%d", &int_input);
	} while (int_input < 1 || int_input > 5);

	//updates the rating
	cur->data.rating = int_input;

	//updates the pointers
	cur->pNext = (*pList)->pNext;
	cur->pPrev = (*pList)->pPrev;
	//changes pList
	*pList = cur;

	while ((*pList)->pPrev != NULL)
	{
		(*pList) = (*pList)->pPrev;
	}
}


/*
 Function: choose_song()
 Date Created: 1/30/23
 Date Last Modified: 1/30/23
 Description: This allows the user to choose the song
 Input parameters: the  pointer to the linked list, the pointer to the song choice
 Returns: nothing
 Preconditions: the list must exist
 Postconditions: the song choice must be updated
*/
void choose_song(Node* pList, char* song_choice)
{
	Node* cur = pList;
	int choices[20], index = 0, index2 = 1, char_index = 0, copy = 0, choice = 0;
	char song[20][30] = { "" };

	while (cur != NULL)
	{
		index2 = 1;
		copy = 0;

		char_index = 0;
		//copies the song onto the array
		strcpy(song[index], cur->data.song_title);


		index++;
		cur = cur->pNext;
	}


	do
	{
		index2 = 0;
		printf("Choose a song: \n");
		//gets the user to choose a song
		while (index2 < index)
		{
			printf("%d: %s\n", index2 + 1, song[index2]);
			index2++;
		}
		scanf("%d", &choice);
	} while (choice < 1 || choice > index + 1);
	//Changes song choice to the user chosen song
	strcpy(song_choice, song[choice - 1]);
}


/*
 Function: play_songs()
 Date Created: 1/30/23
 Date Last Modified: 1/30/23
 Description: This allows the user to play the songs, starting at the one they chose to start on
 Input parameters: the  pointer to the linked list, the pointer to the song choice
 Returns: nothing
 Preconditions: the list must exist, the song choice must also exist
 Postconditions: the songs starting at the one chosen must "play" in order
*/
void play_songs(Node* pList, char* song_choice)
{
	Node* cur = pList;
	while (cur != NULL)
	{
		if (strcmp(cur->data.song_title, song_choice) == 0)
		{
			//we have found the song to start on
			system("pause");
			system("cls");
			while (cur != NULL)
			{
				//says it is playing the current song in the linked list
				printf("Now playing...\n%s, %s, %s, %s, %d:%d, %d, %d\n\n", cur->data.artist, cur->data.album_title, cur->data.song_title,
					cur->data.genre, cur->data.song_length.minutes, cur->data.song_length.seconds, cur->data.times_played, cur->data.rating);
				cur = cur->pNext;
				system("pause");
				system("cls");
			}
			

		}
		else
		{
			//if cur is not what we are looking for, move to next item in list
			cur = cur->pNext;
		}
	}
}


