/*
Programmer name: Sarah Carley
Date made: 4/9/23
Date last modified: 4/9/23
Description: This program detects customer trends
*/

#include "DataAnalysis.hpp"

int main(void)
{
	DataAnalysis obj;
	obj.runAnalysis();


	return 0;
}