/*
Programmer name: Sarah Carley
Date made: 4/9/23
Date last modified: 4/13/23
Description: This program detects customer trends
*/

#include "DataAnalysis.hpp"

/*
 Function: runAnlysis()
 Date Created: 4/11/23
 Date Last Modified: 4/11/23
 Description: runs the whole program
 Input parameters: none
 Returns: nothing
 Preconditions: none
 Postconditions: the program
*/
void DataAnalysis::runAnalysis()
{
    openFile();
    insertData();
    std::cout << "Purchased:" << std::endl;
    treePurchased.inOrderTraversal();
    std::cout << "\n\n\nSold:" << std::endl;
    treeSold.inOrderTraversal();
    displayTrends();
    csvStream.close();
}

/*
Function: openFile()
Date Created: 4/11/23
Date Last Modified: 4/11/23
Description: opens the data file
Input parameters: none
Returns: nothing
Preconditions: none
Postconditions: the file is opened
*/
void DataAnalysis::openFile()
{
	csvStream.open("data.csv");
}

/*
Function: readLine()
Date Created: 4/11/23
Date Last Modified: 4/11/23
Description: reads and separated a line of data
Input parameters: the reference to the unite, type, transaction, and line
Returns: nothing
Preconditions: the values must be passed in (the line must have data values)
Postconditions: the values are set based off the line
*/
void DataAnalysis::readLine(int& units, std::string& type, std::string& transaction, std::string& line)
{
	std::string temp = "", newLine = "";
	int found = 0, i = 0, dec = 0;

    for (; i < (int)line.size() && found == 0; i++)
    {
        if (line[i] != ',') 
        {
            temp += line[i];
        }
        else
        {
            found = 1;
        }
    }
    units = std::stoi(temp);

    found = 0;
    temp = "";
    for (; i < (int)line.size() && found == 0; i++)
    {
        if (line[i] != ',')
        {
            temp += line[i];
        }
        else
        {
            found = 1;
        }
    }
    type = temp;

    found = 0;
    temp = "";
    for (; i < (int)line.size() && found == 0; i++)
    {
        if (line[i] != '\0')
        {
            temp += line[i];
        }
        else
        {
            found = 1;
        }
    }
    transaction = temp;

}

/*
Function: insertData()
Date Created: 4/11/23
Date Last Modified: 4/11/23
Description: calls readLine and insertToTree to read lines and set values to the correct trees
Input parameters: none
Returns: nothing
Preconditions: none
Postconditions: the values are put in the tree based off the line
*/
void DataAnalysis::insertData()
{
    std::string string;
    int units = 0;
    std::string type = "", transaction = "";
    std::getline(csvStream, string);
    while (csvStream)
    {
        std::getline(csvStream, string);
        readLine(units, type, transaction, string);
        insertToTree(units, type, transaction);
    }
}

/*
Function: insertToTree()
Date Created: 4/11/23
Date Last Modified: 4/11/23
Description: figures out what the transaction type is and puts the data in the corresponding tree
Input parameters: the reference to the units, type, and transaction
Returns: nothing
Preconditions: none
Postconditions: the values are put in the tree based off the transaction
*/
void DataAnalysis::insertToTree(int& units, std::string& type, std::string& transaction)
{
    if (transaction == "Purchased")
    {
        treePurchased.insert(type, units);
    }
    else
    {
        treeSold.insert(type, units);
    }
}

/*
Function: displayTrends()
Date Created: 4/13/23
Date Last Modified: 4/13/23
Description: prints out the smallest and largest data for each tree
Input parameters: none
Returns: nothing
Preconditions: none
Postconditions: the trends are printed to the screen
*/
void DataAnalysis::displayTrends()
{
    TransactionNode temp;
    std::cout << "\n\n\n\nTrends for what was purchased:" << std::endl;
    temp = treePurchased.findLargest(treePurchased.getRoot(), temp);
    std::cout << "Most units sold: " << temp.getUnits() << " from product ";
    temp.Node::printData();
    temp = treePurchased.findSmallest(treePurchased.getRoot(), temp);
    std::cout << "Least units sold: " << temp.getUnits() << " from product ";
    temp.Node::printData();

    std::cout << "\n\nTrends for what was sold:" << std::endl;
    temp = treeSold.findLargest(treeSold.getRoot(), temp);
    std::cout << "Most units sold: " << temp.getUnits() << " from product ";
    temp.Node::printData();
    temp = treeSold.findSmallest(treeSold.getRoot(), temp);
    std::cout << "Least units sold: " << temp.getUnits() << " from product ";
    temp.Node::printData();
}
