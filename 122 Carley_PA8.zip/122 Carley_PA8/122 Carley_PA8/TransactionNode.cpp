/*
Programmer name: Sarah Carley
Date made: 4/9/23
Date last modified: 4/10/23
Description: This program detects customer trends
*/

#include "TransactionNode.hpp"

/*
 Function: ~TransactionNode()
 Date Created: 4/10/23
 Date Last Modified: 4/10/23
 Description: destructs the Node
 Input parameters: none
 Returns: nothing
 Preconditions: none
 Postconditions: the node is destructed
*/
TransactionNode::~TransactionNode()
{
}

/*
 Function: setUnits()
 Date Created: 4/10/23
 Date Last Modified: 4/10/23
 Description: swets the value
 Input parameters: the value
 Returns: none
 Preconditions: none
 Postconditions: the value is set
*/
void TransactionNode::setUnits(int& newUnits)
{
	this->units = newUnits;
}

/*
 Function: getUnits()
 Date Created: 4/10/23
 Date Last Modified: 4/10/23
 Description: swets the value
 Input parameters: none
 Returns: the value
 Preconditions: none
 Postconditions: the value is returned
*/
int TransactionNode::getUnits()
{
	return this->units;
}

/*
 Function: printData()
 Date Created: 4/10/23
 Date Last Modified: 4/11/23
 Description: prints the data
 Input parameters: none
 Returns: nothing
 Preconditions: none
 Postconditions: the data of the node is printed
*/
void TransactionNode::printData()
{
	std::cout << "Units: " << this->units << "    Product: ";
}

//4/11
TransactionNode& TransactionNode::operator=(TransactionNode& rhs)
{
	this->data = rhs.getData();
	this->units = rhs.getUnits();
	return *this;
}
