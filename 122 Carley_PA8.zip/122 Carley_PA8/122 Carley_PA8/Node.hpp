/*
Programmer name: Sarah Carley
Date made: 4/9/23
Date last modified: 4/9/23
Description: This program detects customer trends
*/

#pragma once

#include<iostream>
#include<string>
#include<fstream>

class Node
{
public:
	/*
	 Function: Node()
	 Date Created: 4/10/23
	 Date Last Modified: 4/10/23
	 Description: constructs the Node
	 Input parameters: the string
	 Returns: nothing
	 Preconditions: none
	 Postconditions: the node is constructed
	*/
	Node(const std::string& newData = "")
	{
		this->data = newData;
		this->pLeft = nullptr;
		this->pRight = nullptr;
	}


	/*
	 Function: ~Node()
	 Date Created: 4/10/23
	 Date Last Modified: 4/10/23
	 Description: destructs the Node
	 Input parameters: none
	 Returns: nothing
	 Preconditions: none
	 Postconditions: the node is destructed
	*/
	virtual ~Node();


	/*
	 Function: setData()
	 Date Created: 4/10/23
	 Date Last Modified: 4/10/23
	 Description: swets the value
	 Input parameters: the value
	 Returns: none
	 Preconditions: none
	 Postconditions: the value is set
	*/
	void setData(std::string& newData);

	/*
	 Function: setLeftPtr()
	 Date Created: 4/10/23
	 Date Last Modified: 4/10/23
	 Description: swets the value
	 Input parameters: the value
	 Returns: none
	 Preconditions: none
	 Postconditions: the value is set
	*/
	void setLeftPtr(Node* newLeft);

	/*
	 Function: setRightPtr()
	 Date Created: 4/10/23
	 Date Last Modified: 4/10/23
	 Description: swets the value
	 Input parameters: the value
	 Returns: none
	 Preconditions: none
	 Postconditions: the value is set
	*/
	void setRightPtr(Node* newRight);


	/*
	 Function: getData()
	 Date Created: 4/10/23
	 Date Last Modified: 4/10/23
	 Description: gets the value
	 Input parameters: none
	 Returns: the value
	 Preconditions: none
	 Postconditions: the value is returned
	*/
	std::string getData();

	/*
	 Function: getLeft()
	 Date Created: 4/10/23
	 Date Last Modified: 4/10/23
	 Description: gets the value
	 Input parameters: none
	 Returns: the value
	 Preconditions: none
	 Postconditions: the value is returned
	*/
	Node*& getLeft();

	/*
	 Function: getRight()
	 Date Created: 4/10/23
	 Date Last Modified: 4/10/23
	 Description: gets the value
	 Input parameters: none
	 Returns: the value
	 Preconditions: none
	 Postconditions: the value is returned
	*/
	Node*& getRight();

	/*
	 Function: printData()
	 Date Created: 4/10/23
	 Date Last Modified: 4/11/23
	 Description: prints the data
	 Input parameters: none
	 Returns: nothing
	 Preconditions: none
	 Postconditions: the data of the node is printed
	*/
	virtual void printData() = 0;

protected:
	std::string data;
	Node* pLeft;
	Node* pRight;
};