/*
Programmer name: Sarah Carley
Date made: 4/9/23
Date last modified: 4/13/23
Description: This program detects customer trends
*/

#pragma once

#include "TransactionNode.hpp"

class BST
{
public:
	/*
	 Function: BST()
	 Date Created: 4/10/23
	 Date Last Modified: 4/10/23
	 Description: constructs the tree
	 Input parameters: none
	 Returns: nothing
	 Preconditions: none
	 Postconditions: the BST is constructed
	*/
	BST() : pRoot(nullptr) {};

	/*
	 Function: ~BST()
	 Date Created: 4/10/23
	 Date Last Modified: 4/10/23
	 Description: destructs the tree by calling destroyTree
	 Input parameters: none
	 Returns: nothing
	 Preconditions: none
	 Postconditions: the BST is destructed
	*/
	~BST();

	/*
	 Function: setRoot()
	 Date Created: 4/10/23
	 Date Last Modified: 4/10/23
	 Description: sets the root
	 Input parameters: the new node
	 Returns: nothing
	 Preconditions: none
	 Postconditions: the root is set
	*/
	void setRoot(Node* newNode);

	/*
	 Function: getRoot()
	 Date Created: 4/10/23
	 Date Last Modified: 4/10/23
	 Description: gets the root
	 Input parameters: nothing
	 Returns: the root
	 Preconditions: none
	 Postconditions: the root is returned
	*/
	Node*& getRoot();

	/*
	 Function: insert()
	 Date Created: 4/11/23
	 Date Last Modified: 4/11/23
	 Description: calls the insert() helper function
	 Input parameters: the new string and the new units
	 Returns: nothing
	 Preconditions: none
	 Postconditions: the helper function is called
	*/
	void insert(std::string& newString, int& newUnits);

	/*
	 Function: inOrderTraversal()
	 Date Created: 4/11/23
	 Date Last Modified: 4/11/23
	 Description: calls the inOrderTraversal() helper function
	 Input parameters: the none
	 Returns: nothing
	 Preconditions: none
	 Postconditions: the helper function is called
	*/
	void inOrderTraversal();

	/*
	 Function: findSmallest()
	 Date Created: 4/11/23
	 Date Last Modified: 4/11/23
	 Description: recursively calls the function until the node with the smallest units is returned
	 Input parameters: the none
	 Returns: the TransactionNode
	 Preconditions: none
	 Postconditions: the node is returned
	*/
	TransactionNode& findSmallest(Node*& pTree, TransactionNode& node);

	/*
	 Function: findLargest()
	 Date Created: 4/11/23
	 Date Last Modified: 4/11/23
	 Description: recursively calls the function until the node with the largest units is returned
	 Input parameters: the none
	 Returns: the TransactionNode
	 Preconditions: none
	 Postconditions: the node is returned
	*/
	TransactionNode& findLargest(Node*& pTree, TransactionNode& node);

	

private:
	Node* pRoot;
	/*
	 Function: destroyTree()
	 Date Created: 4/13/23
	 Date Last Modified: 4/13/23
	 Description: recursively calls the function until the tree is deleted
	 Input parameters: the node
	 Returns: none
	 Preconditions: none
	 Postconditions: the tree is destroyed
	*/
	void destroyTree(Node*& pTree);

	/*
	Function: insert()
	Date Created : 4 / 11 / 23
	Date Last Modified : 4 / 11 / 23
	Description : inserts the new data into the BST
	Input parameters : the root, the new string and the new units
	Returns : nothing
	Preconditions : none
	Postconditions : the data is added to the BST
	*/
	void insert(Node*& pRoot, std::string& newString, int& newUnits);

	/*
	 Function: inOrderTraversal()
	 Date Created: 4/11/23
	 Date Last Modified: 4/11/23
	 Description: moves through the bst in order and prints the values
	 Input parameters: the node
	 Returns: nothing
	 Preconditions: none
	 Postconditions: the data is printed
	*/
	void inOrderTraversal(Node* pTree);
};