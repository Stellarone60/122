/*
Programmer name: Sarah Carley
Date made: 4/9/23
Date last modified: 4/9/23
Description: This program detects customer trends
*/

#pragma once

#include "Node.hpp"

class TransactionNode : public Node
{
public:
	/*
	 Function: TransactionNode()
	 Date Created: 4/10/23
	 Date Last Modified: 4/10/23
	 Description: constructs the Node
	 Input parameters: the string and the new units
	 Returns: nothing
	 Preconditions: none
	 Postconditions: the node is constructed
	*/
	TransactionNode(const std::string& newData = "", const int& newUnits = 0) : Node(newData)
	{
		units = newUnits;
	}

	/*
	 Function: ~TransactionNode()
	 Date Created: 4/10/23
	 Date Last Modified: 4/10/23
	 Description: destructs the Node
	 Input parameters: none
	 Returns: nothing
	 Preconditions: none
	 Postconditions: the node is destructed
	*/
	~TransactionNode();

	/*
	 Function: setUnits()
	 Date Created: 4/10/23
	 Date Last Modified: 4/10/23
	 Description: swets the value
	 Input parameters: the value
	 Returns: none
	 Preconditions: none
	 Postconditions: the value is set
	*/
	void setUnits(int& newUnits);


	/*
	 Function: getUnits()
	 Date Created: 4/10/23
	 Date Last Modified: 4/10/23
	 Description: swets the value
	 Input parameters: none
	 Returns: the value
	 Preconditions: none
	 Postconditions: the value is returned
	*/
	int getUnits();

	/*
	 Function: printData()
	 Date Created: 4/10/23
	 Date Last Modified: 4/11/23
	 Description: prints the data
	 Input parameters: none
	 Returns: nothing
	 Preconditions: none
	 Postconditions: the data of the node is printed
	*/
	void printData();

	TransactionNode& operator=(TransactionNode& rhs);

private:
	int units;
};