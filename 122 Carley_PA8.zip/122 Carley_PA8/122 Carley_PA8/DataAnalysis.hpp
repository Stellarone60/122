/*
Programmer name: Sarah Carley
Date made: 4/9/23
Date last modified: 4/13/23
Description: This program detects customer trends
*/

#pragma once

#include "BST.hpp"

class DataAnalysis
{
public:

	/*
	 Function: runAnlysis()
	 Date Created: 4/11/23
	 Date Last Modified: 4/11/23
	 Description: runs the whole program
	 Input parameters: none
	 Returns: nothing
	 Preconditions: none
	 Postconditions: the program
	*/
	void runAnalysis();

private:
	BST treeSold;
	BST treePurchased;
	std::ifstream csvStream;

	/*
	Function: openFile()
	Date Created: 4/11/23
	Date Last Modified: 4/11/23
	Description: opens the data file
	Input parameters: none
	Returns: nothing
	Preconditions: none
	Postconditions: the file is opened
	*/
	void openFile();

	/*
	Function: readLine()
	Date Created: 4/11/23
	Date Last Modified: 4/11/23
	Description: reads and separated a line of data
	Input parameters: the reference to the unite, type, transaction, and line
	Returns: nothing
	Preconditions: the values must be passed in (the line must have data values)
	Postconditions: the values are set based off the line
	*/
	void readLine(int& units, std::string& type, std::string& transaction, std::string& line);

	/*
	Function: insertData()
	Date Created: 4/11/23
	Date Last Modified: 4/11/23
	Description: calls readLine and insertToTree to read lines and set values to the correct trees
	Input parameters: none
	Returns: nothing
	Preconditions: none
	Postconditions: the values are put in the tree based off the line
	*/
	void insertData();

	/*
	Function: insertToTree()
	Date Created: 4/11/23
	Date Last Modified: 4/11/23
	Description: figures out what the transaction type is and puts the data in the corresponding tree
	Input parameters: the reference to the units, type, and transaction
	Returns: nothing
	Preconditions: none
	Postconditions: the values are put in the tree based off the transaction
	*/
	void insertToTree(int& units, std::string& type, std::string& transaction);

	/*
	Function: displayTrends()
	Date Created: 4/13/23
	Date Last Modified: 4/13/23
	Description: prints out the smallest and largest data for each tree
	Input parameters: none
	Returns: nothing
	Preconditions: none
	Postconditions: the trends are printed to the screen
	*/
	void displayTrends();

};