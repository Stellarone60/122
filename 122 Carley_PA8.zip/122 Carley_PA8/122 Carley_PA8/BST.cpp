/*
Programmer name: Sarah Carley
Date made: 4/9/23
Date last modified: 4/13/23
Description: This program detects customer trends
*/

#include "BST.hpp"

/*
 Function: ~BST()
 Date Created: 4/10/23
 Date Last Modified: 4/13/23
 Description: destructs the tree by calling destroyTree
 Input parameters: none
 Returns: nothing
 Preconditions: none
 Postconditions: the BST is destructed
*/
BST::~BST()
{
	destroyTree(this->pRoot);
}

/*
 Function: setRoot()
 Date Created: 4/10/23
 Date Last Modified: 4/10/23
 Description: sets the root
 Input parameters: the new node
 Returns: nothing
 Preconditions: none
 Postconditions: the root is set
*/
void BST::setRoot(Node* newNode)
{
	this->pRoot = dynamic_cast<TransactionNode*>(newNode);
}

/*
 Function: getRoot()
 Date Created: 4/10/23
 Date Last Modified: 4/10/23
 Description: gets the root
 Input parameters: nothing
 Returns: the root
 Preconditions: none
 Postconditions: the root is returned
*/
Node*& BST::getRoot()
{
	return this->pRoot;
}

/*
 Function: insert()
 Date Created: 4/11/23
 Date Last Modified: 4/11/23
 Description: calls the insert() helper function
 Input parameters: the new string and the new units
 Returns: nothing
 Preconditions: none
 Postconditions: the helper function is called
*/
void BST::insert(std::string& newString, int& newUnits)
{
	insert(this->pRoot, newString, newUnits);
}

/*
 Function: inOrderTraversal()
 Date Created: 4/11/23
 Date Last Modified: 4/11/23
 Description: calls the inOrderTraversal() helper function
 Input parameters: the none
 Returns: nothing
 Preconditions: none
 Postconditions: the helper function is called
*/
void BST::inOrderTraversal()
{
	inOrderTraversal(this->pRoot);
}

/*
 Function: findSmallest()
 Date Created: 4/11/23
 Date Last Modified: 4/11/23
 Description: recursively calls the function until the node with the smallest units is returned
 Input parameters: the none
 Returns: the TransactionNode
 Preconditions: none
 Postconditions: the node is returned
*/
TransactionNode& BST::findSmallest(Node*& pTree, TransactionNode& node)
{
	if (pTree->getLeft() == nullptr)
	{
		return dynamic_cast<TransactionNode&>(*pTree);
	}
	else
	{
		node = findSmallest(pTree->getLeft(), node);
		return node;
	}
}

/*
 Function: findLargest()
 Date Created: 4/11/23
 Date Last Modified: 4/11/23
 Description: recursively calls the function until the node with the largest units is returned
 Input parameters: the none
 Returns: the TransactionNode
 Preconditions: none
 Postconditions: the node is returned
*/
TransactionNode& BST::findLargest(Node*& pTree, TransactionNode& node)
{
	if (pTree->getRight() == nullptr)
	{
		return dynamic_cast<TransactionNode&>(*pTree);
	}
	else
	{
		node = findLargest(pTree->getRight(), node);
		return node;
	}
}

/*
 Function: destroyTree()
 Date Created: 4/13/23
 Date Last Modified: 4/13/23
 Description: recursively calls the function until the tree is deleted
 Input parameters: the node
 Returns: none
 Preconditions: none
 Postconditions: the tree is destroyed
*/
void BST::destroyTree(Node*& pTree)
{
	if (pTree != nullptr)
	{
		destroyTree(pTree->getLeft());
		destroyTree(pTree->getRight());
		delete(pTree);
	}
}

/*
 Function: insert()
 Date Created: 4/11/23
 Date Last Modified: 4/11/23
 Description: inserts the new data into the BST
 Input parameters: the root, the new string and the new units
 Returns: nothing
 Preconditions: none
 Postconditions: the data is added to the BST
*/
void BST::insert(Node*& pRoot, std::string& newString, int& newUnits)
{
	if (pRoot == nullptr)
	{
		setRoot(new TransactionNode(newString, newUnits));
	}
	else if (dynamic_cast<TransactionNode*>(pRoot)->getUnits() < newUnits)
	{
		if (pRoot->getRight() == nullptr)
		{
			pRoot->setRightPtr(new TransactionNode(newString, newUnits));
		}
		else
		{
			insert(pRoot->getRight(), newString, newUnits);
		}
	}
	else if (dynamic_cast<TransactionNode*>(pRoot)->getUnits() > newUnits)
	{
		if (pRoot->getLeft() == nullptr)
		{
			pRoot->setLeftPtr(new TransactionNode(newString, newUnits));
		}
		else
		{
			insert(pRoot->getLeft(), newString, newUnits);
		}
	}
}

/*
 Function: inOrderTraversal()
 Date Created: 4/11/23
 Date Last Modified: 4/11/23
 Description: moves through the bst in order and prints the values
 Input parameters: the node
 Returns: nothing
 Preconditions: none
 Postconditions: the data is printed
*/
void BST::inOrderTraversal(Node* pTree)
{
	if (pTree != nullptr)
	{
		inOrderTraversal(pTree->getLeft());
		pTree->printData();
		//Node::printData gotten from sth on Stack Overflow
		//https://stackoverflow.com/questions/672373/can-i-call-a-base-classs-virtual-function-if-im-overriding-it
		pTree->Node::printData();
		inOrderTraversal(pTree->getRight());
	}
}
