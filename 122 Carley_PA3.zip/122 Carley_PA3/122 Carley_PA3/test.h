#ifndef TEST_H
#define TEST_H

#include "music.h"

void test_insert(void);

void test_delete(void);

void test_shuffle(void);




#endif