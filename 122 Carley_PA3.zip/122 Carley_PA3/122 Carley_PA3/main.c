/*
Programmer name: Sarah Carley
Date made: 1/28/23
Date last modified: 2/13/23
Description: This is the main function where all the program will be based.
It is a digital music manager which will do things such as load, play, and delete music
*/


/*
This is the data set that the csv file starts with

"Swift, Taylor",1989,Shake it Off,Pop,3:35,12,3
Drake,NOTHING WAS THE SAME,Own it,Rap,3:23,3,3
Drake,YOU WELCOME,The Motto,Rap,4:13,7,4
"Perri, Christina",HEAD OF HEART,Trust,Pop,2:35,3,5
"Bieber, Justin",PURPOSE,No Sense,Pop,4:12,6,1
Eminem,SHADYXV,Vegas,Rap,3:37,8,3
Adele,25,Remedy,Pop,4:11,24,4
"Swift, Taylor",RED,Stay Stay Stay,Pop,4:42,5,1
"Brooks, Garth",FRESH HORSES,The Old Stuff,Country,2:57,11,2



*/



#include "music.h"
#include "test.h"

int main(int agrc, char* argv)
{
	FILE* music_stream = fopen("musicPlayList.csv", "r");
	Node* pHead = NULL, * pTemp = NULL;
	Record data;
	int choice = 0, success = 0, print_choice = 0, songs = 0, sort_choice = 0;
	char line[100] = "", artist_choice[30] = "", temp_line[100] = "", song_choice[30] = "", temp_artist[30] = "";

	srand((unsigned)time(NULL));

	/*
		music_stream = fopen("musicPlayList.csv", "w");
		fprintf(music_stream, "AAAAAAAAAAAA");
		^ how to remove data from a file and replace it
	*/

	int test_choice = 0;
	//test cases
	do
	{
		printf("Would you like to use the test functions?\n1: yes\n2: no\n");
		scanf("%d", &test_choice);
	} while (test_choice < 1 || test_choice > 2);
	if (test_choice == 1)
	{
		test_insert();
		system("pause");
		system("cls");
		test_delete();
		system("pause");
		system("cls");
		test_shuffle();
		system("pause");
		system("cls");
	}
	if (music_stream != NULL)
	{
		choice = get_menu_choice();
		while (choice != 12)
		{

			switch (choice)
			{
			case 1:
				//load
				//opens the csv file for mode read
				music_stream = fopen("musicPlayList.csv", "r");

				while (fgets(line, 100, music_stream) != NULL)
				{
					//parsing
					strcpy(data.artist, strtok(line, ","));
					if (line[0] == '\"')
					{
						//deals with possible commas that are in artist names
						strcat(data.artist, ",");
						strcpy(temp_line, strtok(NULL, ","));
						strcat(data.artist, temp_line);
					}
					//strtok(NULL, ",");
					strcpy(data.album_title, strtok(NULL, ","));
					strcpy(data.song_title, strtok(NULL, ","));
					strcpy(data.genre, strtok(NULL, ","));
					data.song_length.minutes = atoi(strtok(NULL, ":"));
					data.song_length.seconds = atoi(strtok(NULL, ","));
					data.times_played = atoi(strtok(NULL, ","));
					data.rating = atoi(strtok(NULL, "\n"));
					//end of parsing
					success = insert_at_front(&pHead, data);
					//inserts the data into the linked list
					songs++;
				}
				if (success == 1)
				{
					printf("The data has been loaded successfully!\n");
				}
				else
				{
					printf("The data did not load successfully.\n");
				}
				system("pause");
				system("cls");

				choice = get_menu_choice();
				break;
			case 2:
				//store
				if (songs == 0)
				{
					printf("Please either insert a song or load the songs\n");
				}
				else
				{
					pTemp = pHead;
					//opens the stream for mode write
					music_stream = fopen("musicPlayList.csv", "w");
					//prints the values into the stream starting at the head
					while (pTemp != NULL)
					{
						fprintf(music_stream, "%s, %s, %s, %s, %d:%d, %d, %d\n", pTemp->data.artist, pTemp->data.album_title, pTemp->data.song_title,
							pTemp->data.genre, pTemp->data.song_length.minutes, pTemp->data.song_length.seconds, pTemp->data.times_played, pTemp->data.rating);
						pTemp = pTemp->pNext;
					}
				}

				choice = get_menu_choice();
				break;
			case 3:
				//display
				if (songs == 0)
				{
					printf("Please either insert a song or load the songs\n");
				}
				else
				{
					do
						//asks what the user wants to print
					{
						printf("Would you like to: \n1: print off songs from an artist\n2:print off all songs\n");
						scanf("%d", &print_choice);
					} while (print_choice < 0 || print_choice > 2);


					if (print_choice == 1)
					{
						//gets the user to choose an artist, then prints songs from said artist
						choose_artist(pHead, artist_choice);
						success = print_artist(pHead, artist_choice);
					}
					else
					{
						//prints all data
						print_all(pHead);
					}
				}
				

				system("pause");
				system("cls");


				choice = get_menu_choice();
				break;
			case 4:
				//insert
				//function here
				insert(&pHead);
				

				songs++;

				success++;

				system("pause");
				system("cls");
				choice = get_menu_choice();
				break;
			case 5:
				//delete
				if (songs == 0)
				{
					printf("Please either insert a song or load the songs\n");
				}
				else
				{
					//deletes the data based off of the title of the song
					delete_data(&pHead);
					songs--;
				}
				system("pause");
				system("cls");
				choice = get_menu_choice();
				break;
			case 6:
				//edit
				if (songs == 0)
				{
					printf("Please either insert a song or load the songs\n");
				}
				else
				{
					//gets input for which artist
					printf("Which artist would you like to edit the song of?\n");
					choose_artist(pHead, artist_choice);
					//changes the data of the song
					edit_song(&pHead, artist_choice);
				}
				system("pause");
				system("cls");

				choice = get_menu_choice();
				break;
			case 7:
				//sort
				if (songs == 0)
				{
					printf("Please either insert a song or load the songs\n");
				}
				else
				{
					do
					{
						printf("How would you like to sort?\n1: artist (A-Z)\n2: album title (A-Z)\n3: rating (low-high)\n4: times played (high-low)\n");
						scanf("%d", &sort_choice);
					} while (sort_choice < 1 || sort_choice > 4);

					//function here
					sort(&pHead, sort_choice, songs);
				}

				system("pause");
				system("cls");
				choice = get_menu_choice();
				break;
			case 8:
				//rate
				if (songs == 0)
				{
					printf("Please either insert a song or load the songs\n");
				}
				else
				{
					//gets the song that the user wants to change the rating of
					printf("Which artist would you like to edit the rating of?\n");
					choose_artist(pHead, artist_choice);


					//changes teh rating of the chosen song
					edit_rating(&pHead, artist_choice);
				}

				system("pause");
				system("cls");

				choice = get_menu_choice();
				break;
			case 9:
				//play
				if (songs == 0)
				{
					printf("Please either insert a song or load the songs\n");
				}
				else
				{
					//plays the songs starting at the song the user chooses
					choose_song(pHead, song_choice);
					play_songs(pHead, song_choice);
				}

				system("pause");
				system("cls");


				choice = get_menu_choice();
				break;
			case 10:
				//shuffle
				if (songs == 0)
				{
					printf("Please either insert a song or load the songs\n");
				}
				else
				{
					//function goes here
					shuffle(songs, pHead);
				}
				

				system("pause");
				system("cls");

				choice = get_menu_choice();
				break;
			case 11:
				//quit
				pTemp = pHead;
				//opens the file for mode write
				music_stream = fopen("musicPlayList.csv", "w");
				while (pTemp != NULL)
				{
					//writes the data to the file
					fprintf(music_stream, "%s,%s,%s,%s,%d:%d,%d,%d\n", pTemp->data.artist, pTemp->data.album_title, pTemp->data.song_title,
						pTemp->data.genre, pTemp->data.song_length.minutes, pTemp->data.song_length.seconds, pTemp->data.times_played, pTemp->data.rating);
					pTemp = pTemp->pNext;
				}
				choice = 12;
				break;
			}

		}
		//closes the stream
		fclose(music_stream);
	}



	return 0;
}