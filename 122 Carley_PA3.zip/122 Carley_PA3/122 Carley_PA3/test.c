#include "test.h"

void test_insert(void)
{
	Node* pHead = NULL;
	insert(&pHead);
	printf("\nTest case for success passed\n");
	if (pHead != NULL)
	{
		printf("Test case for non empty node passed\n");
		if (strcmp(pHead->data.artist, "\"Perry, Katy\"") == 0)
		{
			printf("Test case for artist passed\n");
			if (strcmp(pHead->data.genre, "pop") == 0)
			{
				printf("Test case for genre passed\n");
				if (strcmp(pHead->data.album_title, "Witness") == 0)
				{
					printf("Test case for album passed\n");
					if (pHead->data.song_length.minutes == 4)
					{
						printf("Test case for minutes passed\n");
						if (pHead->data.song_length.seconds == 36)
						{
							printf("Test case for seconds passed\n");
							if (strcmp(pHead->data.song_title, "Chained to the Rhythm") == 0)
							{
								printf("Test case for song title passed\n");
								if (pHead->data.times_played == -1)
								{
									printf("Test case for times played failed (we are not supposed to have -1)\n");
								}
								else
								{
									printf("Test case for times played passed\n");
									if (pHead->data.rating == 6)
									{
										printf("Test case for times played failed (we are not supposed to have 6\n");
									}
									else
									{
										printf("Test case for times played passed\n");
									}
								}
							}
							else
							{
								printf("Test case for song title failed\n");
							}
						}
						else
						{
							printf("Test case for seconds failed\n");
						}
					}
					else
					{
						printf("Test case for minutes failed\n");
					}
				}
				else
				{
					printf("Test case for album failed\n");
				}
			}
			else
			{
				printf("Test case for genre failed\n");
			}
		}
		else
		{
			printf("Test case for artist failed\n");
		}
	}
	else
	{
		printf("Test case for non empty node failed\n");
	}
	free(pHead);
}

void test_delete(void)
{
	Node* pHead = malloc(sizeof(Node));

	strcpy(pHead->data.album_title, "Witness");
	strcpy(pHead->data.artist, "\"Perry, Katy\"");
	strcpy(pHead->data.genre, "pop");
	strcpy(pHead->data.song_title, "Chained to the Rhythm");
	pHead->data.rating = 5;
	pHead->data.times_played = 3;
	pHead->data.song_length.minutes = 4;
	pHead->data.song_length.seconds = 36;
	pHead->pNext = NULL;
	pHead->pPrev = NULL;

	delete_data(&pHead);

	if (pHead == NULL)
	{
		printf("Test for success has passed\n");
	}
	else
	{
		printf("Test for success has failed\n");
	}
}

void test_shuffle(void)
{
	Node* pHead = malloc(sizeof(Node));

	strcpy(pHead->data.album_title, "Witness");
	strcpy(pHead->data.artist, "\"Perry, Katy\"");
	strcpy(pHead->data.genre, "pop");
	strcpy(pHead->data.song_title, "Chained to the Rhythm");
	pHead->data.rating = 5;
	pHead->data.times_played = 3;
	pHead->data.song_length.minutes = 4;
	pHead->data.song_length.seconds = 36;
	pHead->pNext = NULL;
	pHead->pPrev = NULL;

	Node* pCur = malloc(sizeof(Node));

	strcpy(pCur->data.album_title, "Divisions");
	strcpy(pCur->data.artist, "Starset");
	strcpy(pCur->data.genre, "rock");
	strcpy(pCur->data.song_title, "Echo");
	pCur->data.rating = 5;
	pCur->data.times_played = 12;
	pCur->data.song_length.minutes = 3;
	pCur->data.song_length.seconds = 36;
	pCur->pNext = pHead;
	pHead->pPrev = pCur;
	pCur->pPrev = NULL;
	pHead = pCur;

	Node* pNew = malloc(sizeof(Node));
	strcpy(pNew->data.album_title, "Horizons");
	strcpy(pNew->data.artist, "Starset");
	strcpy(pNew->data.genre, "rock");
	strcpy(pNew->data.song_title, "Tunnelvision");
	pNew->data.rating = 5;
	pNew->data.times_played = 7;
	pNew->data.song_length.minutes = 4;
	pNew->data.song_length.seconds = 19;
	pNew->pNext = pHead;
	pHead->pPrev = pNew;
	pNew->pPrev = NULL;
	pHead = pNew;

	shuffle(3, pHead);

	printf("Test for shuffle has succeeded\n");
}