/*
Programmer name: Sarah Carley
Date made: 1/18/23
Date last modified: 11/26/23
Description: This is the main function where all the program will be based.
It will read data from a file and parse through the data, putting it in a struct
Once that is done, some results will be calculated before being printed to the result file
Then the cleansed data will be printed to the result file
*/

#include "fitbit.h"

int main(int argc, char* argv[])
{
	FILE* FitbitStream = fopen("FitbitData.csv", "rt");
	FILE* ResultStream = fopen("result.csv", "w");
	FitbitData data_table[1440] = { "", "", 0.0, 0.0, 0, 0, 0, 0 };

	char* id = "12cx7", line[100] = "", start[10] = "", end[10] = "";
	int index = 0, compare = 0, dupe = 0, floors = 0, steps = 0, heart_sum = 0, max_step = 0, sleep_range = 0;
	double calories = 0, distance = 0, avg_heartrate = 0.0;


	//checks if the stream is not Null
	if (FitbitStream != NULL)
	{
		//Gets the header and second header
		fgets(line, 100, FitbitStream);
		fgets(line, 100, FitbitStream);
		//Looks through the file
		while (fgets(line, 100, FitbitStream) != NULL)
		{
			//cleanses the data, filling in any empty spots
			data_cleanse(line);

			//Parses the patient number
			strcpy(data_table[index].patient, strtok(line, ","));
			//Parses the minute
			strcpy(data_table[index].minute, strtok(NULL, ","));
			//Parses the calories
			data_table[index].calories = atof(strtok(NULL, ","));
			//Parses the calories
			data_table[index].distance = atof(strtok(NULL, ","));
			//Parses the floors
			data_table[index].floors = atoi(strtok(NULL, ","));
			//Parses the heart rate
			data_table[index].heartRate = atoi(strtok(NULL, ","));
			//Parses the steps
			data_table[index].steps = atoi(strtok(NULL, ","));
			//Parses the sleep level
			data_table[index].sleepLevel = atoi(strtok(NULL, "\n"));
			//Sees if the patient ids are the same
			if (strcmp(id, data_table[index].patient) == 0)
			{
				compare = 1;
			}
			//Checks for any duplicates
			dupe = find_duplicate(data_table, index);
			//if it is not a duplicate and is also the same patient
			if (dupe == 0 && compare == 1)
			{
				//index is changed
				++index;
			}
			//deciding variables are reset
			dupe = 0;
			compare = 0;
		}
	}


	fclose(FitbitStream);

	fprintf(ResultStream, "Total Calories,Total Distance,Total Floors,Total Steps,Avg Heartrate,Max Steps,Sleep\n");

	//calculations
	//using sum double to find the calculations of the calories and distance
	calories = sum_double(data_table, 1, index);
	distance = sum_double(data_table, 2, index);
	//using sum int to find floors and steps
	floors = sum_int(data_table, 1, index);
	steps = sum_int(data_table, 2, index);
	//to calculate the avg heartrate
	heart_sum = sum_int(data_table, 3, index);
	avg_heartrate = heart_sum / (double)index;
	//finds max amount of steps in a minute
	max_step = max_steps(data_table, index);
	//finds longest consecutive poor sleep range
	sleep_range = poor_sleep_range(data_table, index, start, end);

	//print to the file
	fprintf(ResultStream, "%lf,%lf,%d,%d,%lf,%d,%d %s-%s\n", calories, distance, floors, steps, avg_heartrate, max_step,
		sleep_range, start, end);
	//print all data
	print_data(data_table, index, ResultStream);


	fclose(ResultStream);
	return 0;
}