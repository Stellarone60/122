/*
Programmer name: Sarah Carley
Date made: 1/18/23
Date last modified: 1/26/23
Description: This is where the functions will be made in the program
*/

#include "fitbit.h"

/*
 Function: data_cleanse()
 Date Created: 1/23/23
 Date Last Modified: 1/25/23
 Description: This finds missing data and replaces it with invalid data
 Input parameters: the pointer to the string
 Returns: nothing
 Preconditions: the input parameters must exist
 Postconditions: the string, if it has missing data, is updated to include invalid data in that place
*/
void data_cleanse(char* string)
{
	int commas = 0, index = 0, index2 = 0, index3 = 0;
	char temp[100] = "", temp2[100] = "";
	//while the index is not null
	while (string[index] != '\0')
	{
		//add if a comma is seen
		if (string[index] == ',')
		{
			commas++;
		}
		
		//if the current char is a comma and the next one is also a comma
		if (string[index] == ',' && string[index + 1] == ',')
		{
			if (commas == 5)
			{
				while (index2 < index+1)
				{
					//make it so the temp copies the string up until the second comma
					temp[index2] = string[index2];
					index2++;
				}
				//put in the invalid data
				strcat(temp, "0");
				while (string[index2] != NULL)
				{
					//Get the rest of the line
					temp2[index3] = string[index2];
					index2++;
					index3++;
				}
				//update the original line to now have the updated data
				strcat(temp, temp2);
				strcpy(string, temp);
				strcat(string, "\n");
			}
		}
		//if the last value in the line has no data
		else if (string[index] == ',' && string[index + 1] == '\n')
		{
			while (index2 < index+1)
			{
				//make it so the temp copies the string up until the \n
				temp[index2] = string[index2];
				index2++;
			}
			//put in the invalid data then update the original line
			strcat(temp, "0\n");
			strcpy(string, temp);
		}
		index++;
	}
}


/*
 Function: find_duplicate()
 Date Created: 1/23/23
 Date Last Modified: 1/25/23
 Description: This looks through all previous structs to see if this one is a duplicate
 Input parameters: the pointer to the array of structs, the index number
 Returns: whether or not it is a duplicate set of data
 Preconditions: the input parameters must exist
 Postconditions: if it is a duplicate, a 1 will be returned
*/
int find_duplicate(FitbitData *data, int index)
{
	int dec = 1, similar = 0;
	//while the decrement is less than the index
	while (dec < index)
	{
		//compare the current struct's values (besides patient) to the previos structs
		if (strcmp(data[index].minute, data[index - dec].minute) == 0)
		{
			++similar;
			if (data[index].calories == data[index - dec].calories)
			{
				++similar;
				if (data[index].distance == data[index - dec].distance)
				{
					++similar;
					if (data[index].floors == data[index - dec].floors)
					{
						++similar;
						if (data[index].heartRate == data[index - dec].heartRate)
						{
							++similar;
							if (data[index].steps == data[index - dec].steps)
							{
								++similar;
								if (data[index].sleepLevel == data[index - dec].sleepLevel)
								{
									++similar;
								}
							}
						}
					}
				}
			}
		}
		//if all of the values are the same
		if (similar == 7)
		{
			//return that a duplicate has been found
			return 1;
		}
		dec++;
		similar = 0;
	}
	return 0;
}


/*
 Function: sum_double()
 Date Created: 1/25/23
 Date Last Modified: 1/25/23
 Description: This finds the sums of floating point numbers throughout the struct
 Input parameters: the pointer to the array of structs, the index number, which data needs to be added
 Returns: the sum
 Preconditions: the input parameters must exist
 Postconditions: the sum must be returned
*/
double sum_double(FitbitData* data, int which, int max_index)
{
	//which determines if we are calculating calories or distance
	//1 = calories, 2 = distance
	int index = 0;
	double result = 0;

	if (which == 1)
	{
		while (index < max_index)
		{
			//add the calories to the result
			result += data[index].calories;
			index++;
		}
	}
	else
	{
		while (index < max_index)
		{
			//add the distance to the result
			result += data[index].distance;
			index++;
		}
	}
	

	return result;
}


/*
 Function: sum_int()
 Date Created: 1/25/23
 Date Last Modified: 1/25/23
 Description: This finds the sums of integers throughout the struct
 Input parameters: the pointer to the array of structs, the index number, which data needs to be added
 Returns: the sum
 Preconditions: the input parameters must exist
 Postconditions: the sum must be returned
*/
int sum_int(FitbitData* data, int which, int max_index)
{
	//which determines if we are calculating 
	//1 = floors, 2 = steps, 3 = heartrate
	int index = 0, result = 0;

	if (which == 1)
	{
		//add the floors to the result
		while (index < max_index)
		{
			result += data[index].floors;
			index++;
		}
	}
	else if(which == 2)
	{
		while (index < max_index)
		{
			//add the steps to the result
			result += data[index].steps;
			index++;
		}
	}
	else
	{
		while (index < max_index)
		{
			//add the heartRate to the result
			result += data[index].heartRate;
			index++;
		}
	}


	return result;
}


/*
 Function: max_steps()
 Date Created: 1/26/23
 Date Last Modified: 1/26/23
 Description: This finds the highest amount of steps in a minute
 Input parameters: the pointer to the array of structs, the index number
 Returns: the highest number of steps
 Preconditions: the input parameters must exist
 Postconditions: the number of steps must be returned
*/
int max_steps(FitbitData* data, int max_index)
{
	int index = 0, max = 0;
	max = data[index].steps;
	++index;
	while (index < max_index)
	{
		//if the current value of steps is greater than or equal to the mac
		if (data[index].steps >= max)
		{
			//make the data the new max
			max = data[index].steps;
		}
		index++;
	}
	return max;
}

/*
 Function: poor_sleep_range()
 Date Created: 1/26/23
 Date Last Modified: 1/26/23
 Description: This finds the longest consecutive range of poor sleep
 Input parameters: the pointer to the array of structs, the index number, pointers to the start and end of poor sleep
 Returns: the sum of the poor sleep numbers in the range
 Preconditions: the input parameters must exist
 Postconditions: the poor sleep data must be returned
*/
int poor_sleep_range(FitbitData* data, int max_index, char* start_str, char *end_str)
{
	//two lengths and two sums, compare the lengths
	int length1 = 0, max_length = 0, sum = 0, max_sum = 0, index = 0;
	char start[10] = "", end[10] = "";
	while (index < max_index)
	{
		//while the sleep level is poor
		while (data[index].sleepLevel > 1)
		{
			if (length1 == 0)
			{
				//makes the start string into the minute
				strcpy(start, data[index].minute);
			}
			length1++;
			//add to the sum for the sleep level
			sum += data[index].sleepLevel;
			index++;
		}

		if (length1 > 0)
		{
			//makes the end string into the last minute with poor sleep data
			strcpy(end, data[index - 1].minute);
		}
		//if the length of the consecutive sleep levels is more than the max length
		if (length1 > max_length)
		{
			//change the mac length as well as the max sum to the new maxes
			max_length = length1;
			max_sum = sum;
			//updates the minutes
			strcpy(start_str, start);
			strcpy(end_str, end);
		}
		index++;
		sum = 0;
		length1 = 0;
	}
	return max_sum;
}

/*
 Function: print_data()
 Date Created: 1/26/23
 Date Last Modified: 1/26/23
 Description: This prints all of the data from the array of structs to the result file
 Input parameters: the pointer to the array of structs, the index number, and the file
 Returns: nothing
 Preconditions: the input parameters must exist
 Postconditions: the data must be printed in the file
*/
void print_data(FitbitData* data, int max_index, FILE* result)
{
	int index = 0;
	while (index < max_index)
	{
		//print all values to the file in the manner they were in the first file
		fprintf(result, "%s,%s,%lf,%lf,%d,%d,%d,%d\n", data[index].patient, data[index].minute, data[index].calories, data[index].distance,
			data[index].floors, data[index].heartRate, data[index].steps, data[index].sleepLevel);
		index++;
	}
}