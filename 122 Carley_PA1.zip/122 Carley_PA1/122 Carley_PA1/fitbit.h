/*
Programmer name: Sarah Carley
Date made: 1/18/23
Date last modified: 1/26/23
Description: This is where the functions will be called and libraries included
*/

#ifndef FITBIT_H
#define FITBIT_H

#define _CRT_SECURE_NO_WARNINGS

#include<stdio.h>
#include<string.h>
#include<stdlib.h>


typedef enum sleep
{
	NONE = 0, ASLEEP = 1, AWAKE = 2, REALLYAWAKE = 3
} Sleep;

typedef struct fitbit
{
	char patient[10];
	char minute[9];
	double calories;
	double distance;
	unsigned int floors;
	unsigned int heartRate;
	unsigned int steps;
	Sleep sleepLevel;
} FitbitData;


/*
 Function: data_cleanse()
 Date Created: 1/23/23
 Date Last Modified: 1/25/23
 Description: This finds missing data and replaces it with invalid data
 Input parameters: the pointer to the string
 Returns: nothing
 Preconditions: the input parameters must exist
 Postconditions: the string, if it has missing data, is updated to include invalid data in that place
*/
void data_cleanse(char* string);

/*
 Function: find_duplicate()
 Date Created: 1/23/23
 Date Last Modified: 1/25/23
 Description: This looks through all previous structs to see if this one is a duplicate
 Input parameters: the pointer to the array of structs, the index number
 Returns: whether or not it is a duplicate set of data
 Preconditions: the input parameters must exist
 Postconditions: if it is a duplicate, a 1 will be returned
*/
int find_duplicate(FitbitData* data, int index);

/*
 Function: sum_double()
 Date Created: 1/25/23
 Date Last Modified: 1/25/23
 Description: This finds the sums of floating point numbers throughout the struct
 Input parameters: the pointer to the array of structs, the index number, which data needs to be added
 Returns: the sum
 Preconditions: the input parameters must exist
 Postconditions: the sum must be returned
*/
double sum_double(FitbitData* data, int which, int max_index);

/*
 Function: sum_int()
 Date Created: 1/25/23
 Date Last Modified: 1/25/23
 Description: This finds the sums of integers throughout the struct
 Input parameters: the pointer to the array of structs, the index number, which data needs to be added
 Returns: the sum
 Preconditions: the input parameters must exist
 Postconditions: the sum must be returned
*/
int sum_int(FitbitData* data, int which, int max_index);

/*
 Function: max_steps()
 Date Created: 1/26/23
 Date Last Modified: 1/26/23
 Description: This finds the highest amount of steps in a minute
 Input parameters: the pointer to the array of structs, the index number
 Returns: the highest number of steps
 Preconditions: the input parameters must exist
 Postconditions: the number of steps must be returned
*/
int max_steps(FitbitData* data, int max_index);

/*
 Function: poor_sleep_range()
 Date Created: 1/26/23
 Date Last Modified: 1/26/23
 Description: This finds the longest consecutive range of poor sleep
 Input parameters: the pointer to the array of structs, the index number, pointers to the start and end of poor sleep
 Returns: the sum of the poor sleep numbers in the range
 Preconditions: the input parameters must exist
 Postconditions: the poor sleep data must be returned
*/
int poor_sleep_range(FitbitData* data, int max_index, char* start_str, char* end_str);

/*
 Function: print_data()
 Date Created: 1/26/23
 Date Last Modified: 1/26/23
 Description: This prints all of the data from the array of structs to the result file
 Input parameters: the pointer to the array of structs, the index number, and the file
 Returns: nothing
 Preconditions: the input parameters must exist
 Postconditions: the data must be printed in the file
*/
void print_data(FitbitData* data, int max_index, FILE* result);




#endif