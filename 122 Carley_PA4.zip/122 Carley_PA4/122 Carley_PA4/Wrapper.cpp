/*
Name: Sarah Carley
Start date: 2/22/23
Date last edited: 2/28/23
Descrpition: This program will manage the user's exercise plan
*/

#include "Fitness.hpp"
#include "Wrapper.hpp"
/*
Function: runApp()
Date Created: 2/27/23
Date Last Modified: 2/27/23
Description: runs basically the entire fitness app
Input parameters: nothing
Returns: nothing
Preconditions: none
Postconditions: the app runs/has ran
*/
void FitnessAppWrapper::runApp()
{
	//This is basically where the whole program goes
	int choice = 0;
	//gets the user choice from the menu
	choice = displayMenu();
	while (choice != 9)
	{
		switch (choice)
		{
		case 1:
			dietStream.open("Diet.txt");
			loadWeeklyDietPlan(dietStream, diet);
			dietStream.close();
			std::cout << "Data loaded!" << std::endl;
			system("pause");
			system("cls");
			break;
		case 2:
			exerciseStream.open("Exercise.txt");
			loadWeeklyExercisePlan(exerciseStream, exercise);
			exerciseStream.close();
			std::cout << "Data loaded!" << std::endl;
			system("pause");
			system("cls");
			break;
		case 3:
			dietStream.open("Diet.txt");
			dietStream.clear();
			storeWeeklyDietPlan(dietStream, diet);
			dietStream.close();
			std::cout << "Data stored!" << std::endl;
			system("pause");
			system("cls");
			break;
		case 4:
			exerciseStream.open("Exercise.txt");
			exerciseStream.clear();
			storeWeeklyExercisePlan(exerciseStream, exercise);
			exerciseStream.close();
			std::cout << "Data stored!" << std::endl;
			system("pause");
			system("cls");
			break;
		case 5:
			displayWeeklyDietPlan(diet);
			system("pause");
			system("cls");
			break;
		case 6:
			displayWeeklyExercisePlan(exercise);
			system("pause");
			system("cls");
			break;
		case 7:
			//edit day diet
			editDailyDietPlan(diet);
			break;
		case 8:
			//edit day exercise
			editDailyExercisePlan(exercise);
			break;
		}

		choice = displayMenu();
	}
	//storing weekly diet plan once program closes
	dietStream.open("Diet.txt");
	dietStream.clear();
	storeWeeklyDietPlan(dietStream, diet);
	dietStream.close();
	//storing weekly exercise plan once program closes
	exerciseStream.open("Exercise.txt");
	exerciseStream.clear();
	storeWeeklyExercisePlan(exerciseStream, exercise);
	exerciseStream.close();
	
}

/*
Function: loadDailyDietPlan()
Date Created: 2/27/23
Date Last Modified: 2/27/23
Description: loads a day from the file into the weekly plan
Input parameters: the file strea, the plan, and the index
Returns: nothing
Preconditions: none
Postconditions: the information is read
*/
void FitnessAppWrapper::loadDailyDietPlan(std::fstream& fileStream, DietPlan weeklyPlan[], int index)
{
	fileStream >> weeklyPlan[index];
}

/*
Function: loadDailyExercisePlan()
Date Created: 2/27/23
Date Last Modified: 2/27/23
Description: loads a day from the file into the weekly plan
Input parameters: the file strea, the plan, and the index
Returns: nothing
Preconditions: none
Postconditions: the information is read
*/
void FitnessAppWrapper::loadDailyExercisePlan(std::fstream& fileStream, ExercisePlan weeklyPlan[], int index)
{
	fileStream >> weeklyPlan[index];
}

/*
Function: loadWeeklyDietPlan()
Date Created: 2/27/23
Date Last Modified: 1/1/23
Description: loads a week from the file into the weekly plan
Input parameters: the file stream and the plan
Returns: nothing
Preconditions: none
Postconditions: the information is read
*/
void FitnessAppWrapper::loadWeeklyDietPlan(std::fstream& fileStream, DietPlan weeklyPlan[])
{
	int index = 0;
	while (index <= 6)
	{
		loadDailyDietPlan(fileStream, weeklyPlan, index);
		index++;
	}
}

/*
Function: loadWeeklyExercisePlan()
Date Created: 2/27/23
Date Last Modified: 1/1/23
Description: loads a week from the file into the weekly plan
Input parameters: the file stream and the plan
Returns: nothing
Preconditions: none
Postconditions: the information is read
*/
void FitnessAppWrapper::loadWeeklyExercisePlan(std::fstream& fileStream, ExercisePlan weeklyPlan[])
{
	int index = 0;
	while (index <= 6)
	{
		loadDailyExercisePlan(fileStream, weeklyPlan, index);
		index++;
	}
}

/*
Function: displayDailyDietPlan()
Date Created: 2/27/23
Date Last Modified: 2/28/23
Description: prints a day to the screen
Input parameters: the plan
Returns: nothing
Preconditions: there must be data in the plan
Postconditions: the information is printed
*/
void FitnessAppWrapper::displayDailyDietPlan(DietPlan& rhs)
{
	std::cout << rhs;
	std::cout << "\n\n";
}

/*
Function: displayDailyExercisePlan()
Date Created: 2/27/23
Date Last Modified: 2/28/23
Description: prints a day to the screen
Input parameters: the plan
Returns: nothing
Preconditions: there must be data in the plan
Postconditions: the information is printed
*/
void FitnessAppWrapper::displayDailyExercisePlan(ExercisePlan& rhs)
{
	std::cout << rhs;
	std::cout << "\n\n";
}

/*
Function: displayWeeklyDietPlan()
Date Created: 2/27/23
Date Last Modified: 2/28/23
Description: prints a week to the screen
Input parameters: the plan
Returns: nothing
Preconditions: there must be data in the plan
Postconditions: the information is printed
*/
void FitnessAppWrapper::displayWeeklyDietPlan(DietPlan rhs[])
{
	int index = 0;
	while (index <= 6)
	{
		displayDailyDietPlan(rhs[index]);
		index++;
	}
}

/*
Function: displayWeeklyExercisePlan()
Date Created: 2/27/23
Date Last Modified: 2/28/23
Description: prints a week to the screen
Input parameters: the plan
Returns: nothing
Preconditions: there must be data in the plan
Postconditions: the information is printed
*/
void FitnessAppWrapper::displayWeeklyExercisePlan(ExercisePlan rhs[])
{
	int index = 0;
	while (index <= 6)
	{
		displayDailyExercisePlan(rhs[index]);
		index++;
	}
}

/*
Function: storeDailyDietPlan()
Date Created: 2/27/23
Date Last Modified: 2/28/23
Description: prints a day to the file
Input parameters: the plan and the file stream
Returns: nothing
Preconditions: there must be data in the plan
Postconditions: the information is printed to the file
*/
void FitnessAppWrapper::storeDailyDietPlan(std::fstream& fileStream, DietPlan& plan)
{
	fileStream << plan;
	fileStream << "\n\n";
}

/*
Function: storeDailyExercisePlan()
Date Created: 2/27/23
Date Last Modified: 2/28/23
Description: prints a day to the file
Input parameters: the plan and the file stream
Returns: nothing
Preconditions: there must be data in the plan
Postconditions: the information is printed to the file
*/
void FitnessAppWrapper::storeDailyExercisePlan(std::fstream& fileStream, ExercisePlan& plan)
{
	fileStream << plan;
	fileStream << "\n\n";
}

/*
Function: storeWeeklyDietPlan()
Date Created: 2/27/23
Date Last Modified: 2/28/23
Description: prints a week to the file
Input parameters: the plan and the file stream
Returns: nothing
Preconditions: there must be data in the plan
Postconditions: the information is printed to the file
*/
void FitnessAppWrapper::storeWeeklyDietPlan(std::fstream& fileStream, DietPlan plan[])
{
	int index = 0;
	while (index <= 6)
	{
		storeDailyDietPlan(fileStream, plan[index]);
		index++;
	}
}

/*
Function: storeWeeklyExercisePlan()
Date Created: 2/27/23
Date Last Modified: 2/28/23
Description: prints a week to the file
Input parameters: the plan and the file stream
Returns: nothing
Preconditions: there must be data in the plan
Postconditions: the information is printed to the file
*/
void FitnessAppWrapper::storeWeeklyExercisePlan(std::fstream& fileStream, ExercisePlan plan[])
{
	int index = 0;
	while (index <= 6)
	{
		storeDailyExercisePlan(fileStream, plan[index]);
		index++;
	}
}

/*
Function: editDailyDietPlan()
Date Created: 2/27/23
Date Last Modified: 2/28/23
Description: allows the user to change a day in the plan
Input parameters: the plan
Returns: nothing
Preconditions: there must be changeable data in the plan
Postconditions: the information is changed
*/
void FitnessAppWrapper::editDailyDietPlan(DietPlan plan[])
{
	int new_cal = 0, choice = 0;
	std::cout << "which day's plan would you like to edit?" << std::endl;
	system("pause");
	while (choice <= 6)
	{
		//prints off the plans, putting numbers on top of them for user input
		std::cout << choice + 1 << ":" << std::endl;
		displayDailyDietPlan(plan[choice]);
		choice++;
	}
	choice = 0;
	std::string newstr = "";
	do
	{
		//gets user choice
		std::cin >> choice;
	} while (choice < 1 || choice > 7);
	choice -= 1;
	//gets the new name
	std::cout << "What would you like the new plan name to be?" << std::endl;
	std::cin.ignore();
	std::getline(std::cin, newstr);
	//sets the new name
	plan[choice].setplanName(newstr);
	//gets the new calorie goal
	std::cout << "What would you like your new calorie goal to be?" << std::endl;
	std::cin >> new_cal;
	//sets the new calorie goal
	plan[choice].setGoalCalories(new_cal);
	//gets the new date
	std::cout << "What would you like the new date to be? (format of mm/dd/yyyy)" << std::endl;
	std::cin >> newstr;
	//sets the new date
	plan[choice].setDate(newstr);
}

/*
Function: editDailyExercisePlan()
Date Created: 2/27/23
Date Last Modified: 2/28/23
Description: allows the user to change a day in the plan
Input parameters: the plan
Returns: nothing
Preconditions: there must be changeable data in the plan
Postconditions: the information is changed
*/
void FitnessAppWrapper::editDailyExercisePlan(ExercisePlan plan[])
{
	int new_steps = 0, choice = 0;
	std::cout << "which day's plan would you like to edit?" << std::endl;
	system("pause");
	while (choice <= 6)
	{
		//prints off the plans, putting numbers on top of them for user input
		std::cout << choice + 1 << ":" << std::endl;
		displayDailyExercisePlan(plan[choice]);
		choice++;
	}
	choice = 0;
	std::string newstr = "";
	do
	{
		//gets user choice
		std::cin >> choice;
	} while (choice < 1 || choice > 7);
	choice -= 1;
	//gets the new name
	std::cout << "What would you like the new plan name to be?" << std::endl;
	std::cin.ignore();
	std::getline(std::cin, newstr);
	//sets the new name
	plan[choice].setplanName(newstr);
	//gets the new step goal
	std::cout << "What would you like your new step goal to be?" << std::endl;
	std::cin >> new_steps;
	//sets the new step goal
	plan[choice].setGoalSteps(new_steps);
	//gets the new date
	std::cout << "What would you like the new date to be? (format of mm/dd/yyyy)" << std::endl;
	std::cin >> newstr;
	//sets the new date
	plan[choice].setDate(newstr);
}

/*
Function: displayMenu()
Date Created: 2/27/23
Date Last Modified: 2/28/23
Description: allows displays the menu and gets user input
Input parameters: none
Returns: the choice
Preconditions: none
Postconditions: the choice is returned
*/
int FitnessAppWrapper::displayMenu()
{
	int choice = 0;
	do
	{
		std::cout << "1. Load weekly diet plan from file. \n2. Load weekly exercise plan from file.\n3. Store weekly diet plan to file." << std::endl;
		std::cout << "4. Store weekly exercise plan to file.\n5. Display weekly diet plan to screen.\n6. Display weekly exercise plan to screen." << std::endl;
		std::cout << "7. Edit daily diet plan.\n8. Edit daily exercise plan.\n9. Exit." << std::endl;
		std::cin >> choice;
	} while (choice < 1 || choice > 9);
	return choice;
}
