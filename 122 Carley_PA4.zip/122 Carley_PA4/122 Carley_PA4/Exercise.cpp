/*
Name: Sarah Carley
Start date: 2/22/23
Date last edited: 2/27/23
Descrpition: This program will manage the user's exercise plan
*/

#include "Fitness.hpp"
#include "Exercise.hpp"

/*
 Function: ExercisePlan()
 Date Created: 2/26/23
 Date Last Modified: 2/26/23
 Description: This sets the plan to default values when called
 Input parameters: none
 Returns: nothing
 Preconditions: none
 Postconditions: the dafault values are set
*/
ExercisePlan::ExercisePlan()
{
	goalSteps = -1;
	date = "";
	planName = "";
}

/*
 Function: ExercisePlan()
 Date Created: 2/26/23
 Date Last Modified: 2/26/23
 Description: This sets the plan to another plan when called (copy constructor)
 Input parameters: The exercise plan that is being copied onto this one
 Returns: nothing
 Preconditions: none
 Postconditions: the values are changed
*/
ExercisePlan::ExercisePlan(ExercisePlan& copy)
{
	goalSteps = copy.goalSteps;
	planName = copy.planName;
	date = copy.date;
}

/*
 Function: setGoalSteps()
 Date Created: 2/26/23
 Date Last Modified: 2/26/23
 Description: This sets the goal based on the parameter
 Input parameters: The new goal
 Returns: nothing
 Preconditions: none
 Postconditions: the value is changed
*/
void ExercisePlan::setGoalSteps(int goal)
{
	goalSteps = goal;
}

//start: 2/26
/*
 Function: setplanName()
 Date Created: 2/26/23
 Date Last Modified: 2/26/23
 Description: This sets the name based on the parameter
 Input parameters: The new name
 Returns: nothing
 Preconditions: none
 Postconditions: the value is changed
*/
void ExercisePlan::setplanName(std::string name)
{
	planName = name;
}

/*
Function: setDate()
Date Created: 2/26/23
Date Last Modified: 2/26/23
Description: This sets the date based on the parameter
Input parameters: The date
Returns: nothing
Preconditions: none
Postconditions: the value is changed
*/
void ExercisePlan::setDate(std::string newDate)
{
	date = newDate;
}

/*
Function: editGoal()
Date Created: 2/26/23
Date Last Modified: 2/26/23
Description: This sets the new goal based on the user input
Input parameters: nothing
Returns: nothing
Preconditions: none
Postconditions: the value is changed
*/
void ExercisePlan::editGoal(void)
{
	int goal = 0;
	std::cout << "Please insert your new goal:" << std::endl;
	std::cin >> goal;
	goalSteps = goal;
	//display new plan here or in the app part after this is called
}

/*
Function: getGoalSteps()
Date Created: 2/26/23
Date Last Modified: 2/26/23
Description: returns the goal steps
Input parameters: none
Returns: the goal steps
Preconditions: none
Postconditions: goal steps are returned
*/
int ExercisePlan::getGoalSteps()
{
	return goalSteps;
}

/*
Function: getPlanName()
Date Created: 2/26/23
Date Last Modified: 2/26/23
Description: returns the plan name
Input parameters: none
Returns: the plan name
Preconditions: none
Postconditions: the plan name is returned
*/
std::string ExercisePlan::getPlanName()
{
	return planName;
}

/*
Function: getDate()
Date Created: 2/26/23
Date Last Modified: 2/26/23
Description: returns the date
Input parameters: none
Returns: the date
Preconditions: none
Postconditions: the date name is returned
*/
std::string ExercisePlan::getDate()
{
	return date;
}

/*
Function: operator=()
Date Created: 2/26/23
Date Last Modified: 2/26/23
Description: overloads the = operator for the copy constructor
Input parameters: none
Returns: the this pointer
Preconditions: none
Postconditions: the this pointer is returned
*/
ExercisePlan& ExercisePlan::operator=(ExercisePlan& rhs)
{
	goalSteps = rhs.goalSteps;
	planName = rhs.planName;
	date = rhs.date;
	return *this;
}

/*
Function: ~DietPlan()
Date Created: 2/26/23
Date Last Modified: 2/26/23
Description: destructs the plan
Input parameters: none
Returns: nothing
Preconditions: none
Postconditions: nothing
*/
ExercisePlan::~ExercisePlan()
{
	std::cout << "ExercisePlan Destructed" << std::endl;
	//make sure to delete later, leave this empty
}

/*
Function: operator<<()
Date Created: 2/26/23
Date Last Modified: 2/26/23
Description: overloads the << operator for printing to the screen
Input parameters: the output stream and the plan
Returns: the output stream
Preconditions: none
Postconditions: the output stream is returned
*/
std::ostream& operator<<(std::ostream& lhs, ExercisePlan& rhs)
{
	lhs << rhs.getPlanName() << "\n" << rhs.getDate() << "\nGoal steps: " << rhs.getGoalSteps();
	return lhs;
}

/*
Function: operator<<()
Date Created: 2/26/23
Date Last Modified: 2/26/23
Description: overloads the << operator for printing to the file
Input parameters: the file stream and the plan
Returns: the file stream
Preconditions: none
Postconditions: the file stream is returned
*/
std::fstream& operator<<(std::fstream& lhs, ExercisePlan& rhs)
{
	lhs << rhs.getPlanName();
	lhs << "\n" << rhs.getGoalSteps() << "\n" << rhs.getDate();
	return lhs;
}

/*
Function: operator>>()
Date Created: 2/26/23
Date Last Modified: 2/27/23
Description: overloads the >> operator for reading from the file
Input parameters: the file stream and the plan
Returns: the file stream
Preconditions: none
Postconditions: the file stream is returned and the plan changed
*/
std::fstream& operator>>(std::fstream& lhs, ExercisePlan& rhs)
{
	int goal = 0;
	std::string string;

	std::getline(lhs, string);
	rhs.setplanName(string);

	lhs >> goal;
	rhs.setGoalSteps(goal);

	lhs >> string;
	rhs.setDate(string);

	//these two lines of code below gotten via StackOverflow from user cornstalks
	//https://stackoverflow.com/questions/12611465/reading-from-a-file-using-an-overloaded-operator
	lhs.ignore(1024, '\n');
	lhs.ignore(1024, '\n');

	return lhs;
}