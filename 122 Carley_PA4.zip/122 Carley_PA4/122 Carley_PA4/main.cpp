/*
Name: Sarah Carley
Start date: 2/22/23
Date last edited: 2/28/23
Descrpition: This program will manage the user's exercise plan
*/

#include "Wrapper.hpp"



int main(void)
{
	/*
	Diet plan placeholder in case stuff gets messed up
	Plan 1
	2200
	01/01/2023

	Plan 2
	2223
	01/02/2023

	Plan 3
	2214
	01/03/2023

	Plan 4
	1902
	01/04/2023

	Plan 5
	2345
	01/05/2023

	Plan 6
	2665
	01/06/2023

	Plan 7
	2774
	01/07/2023
	*/

	/*
	Exercise placeholder in case stuff gets messed up
	Plan 1
	2212
	01/01/2023

	Plan 2
	2445
	01/02/2023

	Plan 3
	3244
	01/03/2023

	Plan 4
	4432
	01/04/2023

	Plan 5
	2145
	01/05/2023

	Plan 6
	2341
	01/06/2023

	Plan 7
	3333
	01/07/2023
	*/

	FitnessAppWrapper app;

	//call app.runApp
	app.runApp();



	return 0;
}