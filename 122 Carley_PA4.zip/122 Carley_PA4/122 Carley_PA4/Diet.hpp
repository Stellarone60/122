/*
Name: Sarah Carley
Start date: 2/22/23
Date last edited: 2/27/23
Descrpition: This program will manage the user's exercise plan
*/

#pragma once


#include "Fitness.hpp"

class DietPlan
{
public:
	//constructor
	/*
	 Function: DietPlan()
	 Date Created: 2/26/23
	 Date Last Modified: 2/26/23
	 Description: This sets the plan to default values when called
	 Input parameters: none
	 Returns: nothing
	 Preconditions: none
	 Postconditions: the dafault values are set
	*/
	DietPlan();

	//copy constructor
	/*
	 Function: DietPlan()
	 Date Created: 2/26/23
	 Date Last Modified: 2/26/23
	 Description: This sets the plan to another plan when called (copy constructor)
	 Input parameters: The diet plan that is being copied onto this one
	 Returns: nothing
	 Preconditions: none
	 Postconditions: the values are changed
	*/
	DietPlan(DietPlan& copy);

	//setters
	/*
	 Function: setGoalCalories()
	 Date Created: 2/26/23
	 Date Last Modified: 2/26/23
	 Description: This sets the goal based on the parameter
	 Input parameters: The new goal
	 Returns: nothing
	 Preconditions: none
	 Postconditions: the value is changed
	*/
	void setGoalCalories(int goal);
	/*
	 Function: setplanName()
	 Date Created: 2/26/23
	 Date Last Modified: 2/26/23
	 Description: This sets the name based on the parameter
	 Input parameters: The new name
	 Returns: nothing
	 Preconditions: none
	 Postconditions: the value is changed
	*/
	void setplanName(std::string name);
	/*
	 Function: setDate()
	 Date Created: 2/26/23
	 Date Last Modified: 2/26/23
	 Description: This sets the date based on the parameter
	 Input parameters: The date
	 Returns: nothing
	 Preconditions: none
	 Postconditions: the value is changed
	*/
	void setDate(std::string newDate);

	/*
	Function: editGoal()
	Date Created: 2/26/23
	Date Last Modified: 2/26/23
	Description: This sets the new goal based on the user input
	Input parameters: nothing
	Returns: nothing
	Preconditions: none
	Postconditions: the value is changed
	*/
	void editGoal(void);

	//getters
	/*
	Function: getGoalCalories()
	Date Created: 2/26/23
	Date Last Modified: 2/26/23
	Description: returns the goal calories
	Input parameters: none
	Returns: the goal calories
	Preconditions: none
	Postconditions: goal calories is returned
	*/
	int getGoalCalories();
	/*
	Function: getPlanName()
	Date Created: 2/26/23
	Date Last Modified: 2/26/23
	Description: returns the plan name
	Input parameters: none
	Returns: the plan name
	Preconditions: none
	Postconditions: the plan name is returned
	*/
	std::string getPlanName();
	/*
	Function: getDate()
	Date Created: 2/26/23
	Date Last Modified: 2/26/23
	Description: returns the date
	Input parameters: none
	Returns: the date
	Preconditions: none
	Postconditions: the date name is returned
	*/
	std::string getDate();

	//overloader
	/*
	Function: operator=()
	Date Created: 2/26/23
	Date Last Modified: 2/26/23
	Description: overloads the = operator for the copy constructor
	Input parameters: none
	Returns: the this pointer
	Preconditions: none
	Postconditions: the this pointer is returned
	*/
	DietPlan& operator=(DietPlan& rhs);

	//destructor
	/*
	Function: ~DietPlan()
	Date Created: 2/26/23
	Date Last Modified: 2/26/23
	Description: destructs the plan
	Input parameters: none
	Returns: nothing
	Preconditions: none
	Postconditions: nothing
	*/
	~DietPlan();

private:
	int goalCalories;
	std::string planName;
	std::string date;
};


//overload operators

//displaying to screen
/*
Function: operator<<()
Date Created: 2/26/23
Date Last Modified: 2/26/23
Description: overloads the << operator for printing to the screen
Input parameters: the output stream and the plan
Returns: the output stream
Preconditions: none
Postconditions: the output stream is returned
*/
std::ostream& operator<<(std::ostream& lhs, DietPlan& rhs);
//writing to a file
/*
Function: operator<<()
Date Created: 2/26/23
Date Last Modified: 2/26/23
Description: overloads the << operator for printing to the file
Input parameters: the file stream and the plan
Returns: the file stream
Preconditions: none
Postconditions: the file stream is returned
*/
std::fstream& operator<<(std::fstream& lhs, DietPlan& rhs);
//reading from a file
/*
Function: operator>>()
Date Created: 2/26/23
Date Last Modified: 2/27/23
Description: overloads the >> operator for reading from the file
Input parameters: the file stream and the plan
Returns: the file stream
Preconditions: none
Postconditions: the file stream is returned and the plan changed
*/
std::fstream& operator>> (std::fstream& lhs, DietPlan& rhs);