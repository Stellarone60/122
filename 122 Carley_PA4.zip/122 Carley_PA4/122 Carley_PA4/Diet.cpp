/*
Name: Sarah Carley
Start date: 2/22/23
Date last edited: 2/27/23
Descrpition: This program will manage the user's exercise plan
*/

#include "Diet.hpp"

/*
 Function: DietPlan()
 Date Created: 2/26/23
 Date Last Modified: 2/26/23
 Description: This sets the plan to default values when called
 Input parameters: none
 Returns: nothing
 Preconditions: none
 Postconditions: the dafault values are set
*/
DietPlan::DietPlan()
{
	goalCalories = -1;
	planName = "";
	date = "";
}

/*
 Function: DietPlan()
 Date Created: 2/26/23
 Date Last Modified: 2/26/23
 Description: This sets the plan to another plan when called (copy constructor)
 Input parameters: The diet plan that is being copied onto this one
 Returns: nothing
 Preconditions: none
 Postconditions: the values are changed
*/
DietPlan::DietPlan(DietPlan& copy)
{
	goalCalories = copy.goalCalories;
	date = copy.date;
	planName = copy.planName;
}

//start: 2/26
/*
 Function: setGoalCalories()
 Date Created: 2/26/23
 Date Last Modified: 2/26/23
 Description: This sets the goal based on the parameter
 Input parameters: The new goal
 Returns: nothing
 Preconditions: none
 Postconditions: the value is changed
*/
void DietPlan::setGoalCalories(int goal)
{
	goalCalories = goal;
}

/*
 Function: setplanName()
 Date Created: 2/26/23
 Date Last Modified: 2/26/23
 Description: This sets the name based on the parameter
 Input parameters: The new name
 Returns: nothing
 Preconditions: none
 Postconditions: the value is changed
*/
void DietPlan::setplanName(std::string name)
{
	planName = name;
}

/*
Function: setDate()
Date Created: 2/26/23
Date Last Modified: 2/26/23
Description: This sets the date based on the parameter
Input parameters: The date
Returns: nothing
Preconditions: none
Postconditions: the value is changed
*/
void DietPlan::setDate(std::string newDate)
{
	date = newDate;
}

/*
Function: editGoal()
Date Created: 2/26/23
Date Last Modified: 2/26/23
Description: This sets the new goal based on the user input
Input parameters: nothing
Returns: nothing
Preconditions: none
Postconditions: the value is changed
*/
void DietPlan::editGoal(void)
{
	int goal = 0;
	std::cout << "Please insert your new goal:" << std::endl;
	std::cin >> goal;
	goalCalories = goal;
}

/*
Function: getGoalCalories()
Date Created: 2/26/23
Date Last Modified: 2/26/23
Description: returns the goal calories
Input parameters: none
Returns: the goal calories
Preconditions: none
Postconditions: goal calories is returned
*/
int DietPlan::getGoalCalories()
{
	return goalCalories;
}

/*
Function: getPlanName()
Date Created: 2/26/23
Date Last Modified: 2/26/23
Description: returns the plan name
Input parameters: none
Returns: the plan name
Preconditions: none
Postconditions: the plan name is returned
*/
std::string DietPlan::getPlanName()
{
	return planName;
}

/*
Function: getDate()
Date Created: 2/26/23
Date Last Modified: 2/26/23
Description: returns the date
Input parameters: none
Returns: the date
Preconditions: none
Postconditions: the date name is returned
*/
std::string DietPlan::getDate()
{
	return date;
}

/*
Function: operator=()
Date Created: 2/26/23
Date Last Modified: 2/26/23
Description: overloads the = operator for the copy constructor
Input parameters: none
Returns: the this pointer
Preconditions: none
Postconditions: the this pointer is returned
*/
DietPlan& DietPlan::operator=(DietPlan& rhs)
{
	goalCalories = rhs.goalCalories;
	planName = rhs.planName;
	date = rhs.date;
	return *this;
}

/*
Function: ~DietPlan()
Date Created: 2/26/23
Date Last Modified: 2/26/23
Description: destructs the plan
Input parameters: none
Returns: nothing
Preconditions: none
Postconditions: nothing
*/
DietPlan::~DietPlan()
{
}

/*
Function: operator<<()
Date Created: 2/26/23
Date Last Modified: 2/26/23
Description: overloads the << operator for printing to the screen
Input parameters: the output stream and the plan
Returns: the output stream
Preconditions: none
Postconditions: the output stream is returned
*/
std::ostream& operator<<(std::ostream& lhs,  DietPlan& rhs)
{
	lhs << rhs.getPlanName() << "\n" << rhs.getDate() << "\nGoal calories: " << rhs.getGoalCalories();

	return lhs;
}

/*
Function: operator<<()
Date Created: 2/26/23
Date Last Modified: 2/26/23
Description: overloads the << operator for printing to the file
Input parameters: the file stream and the plan
Returns: the file stream
Preconditions: none
Postconditions: the file stream is returned
*/
std::fstream& operator<<(std::fstream& lhs, DietPlan& rhs)
{
	lhs << rhs.getPlanName() << "\n" << rhs.getGoalCalories() << "\n" << rhs.getDate();
	return lhs;
}

/*
Function: operator>>()
Date Created: 2/26/23
Date Last Modified: 2/27/23
Description: overloads the >> operator for reading from the file
Input parameters: the file stream and the plan
Returns: the file stream
Preconditions: none
Postconditions: the file stream is returned and the plan changed
*/
std::fstream& operator>>(std::fstream& lhs, DietPlan& rhs)
{
	int goal = 0;
	std::string string = "";

	std::getline(lhs, string);
	rhs.setplanName(string);

	lhs >> goal;
	rhs.setGoalCalories(goal);

	lhs >> string;
	rhs.setDate(string);

	//these two lines of code below gotten via StackOverflow from user cornstalks
	//https://stackoverflow.com/questions/12611465/reading-from-a-file-using-an-overloaded-operator
	lhs.ignore(1024, '\n');
	lhs.ignore(1024, '\n');

	return lhs;
}
