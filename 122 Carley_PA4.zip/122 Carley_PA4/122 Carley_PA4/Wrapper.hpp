/*
Name: Sarah Carley
Start date: 2/22/23
Date last edited: 2/28/23
Descrpition: This program will manage the user's exercise plan
*/

#pragma once

#include "Exercise.hpp"

class FitnessAppWrapper
{
public:
	/*
	Function: runApp()
	Date Created: 2/27/23
	Date Last Modified: 2/27/23
	Description: runs basically the entire fitness app
	Input parameters: nothing
	Returns: nothing
	Preconditions: none
	Postconditions: the app runs/has ran
	*/
	void runApp();

	//daily plans
	/*
	Function: loadDailyDietPlan()
	Date Created: 2/27/23
	Date Last Modified: 2/27/23
	Description: loads a day from the file into the weekly plan
	Input parameters: the file strea, the plan, and the index
	Returns: nothing
	Preconditions: none
	Postconditions: the information is read
	*/
	void loadDailyDietPlan(std::fstream& fileStream, DietPlan weeklyPlan[], int index);

	/*
	Function: loadDailyDietPlan()
	Date Created: 2/27/23
	Date Last Modified: 2/27/23
	Description: loads a day from the file into the weekly plan
	Input parameters: the file strea, the plan, and the index
	Returns: nothing
	Preconditions: none
	Postconditions: the information is read
	*/
	void loadDailyExercisePlan(std::fstream& fileStream, ExercisePlan weeklyPlan[], int index);
	//weekly plans
	/*
	Function: loadWeeklyDietPlan()
	Date Created: 2/27/23
	Date Last Modified: 1/1/23
	Description: loads a week from the file into the weekly plan
	Input parameters: the file stream and the plan
	Returns: nothing
	Preconditions: none
	Postconditions: the information is read
	*/
	void loadWeeklyDietPlan(std::fstream& fileStream, DietPlan weeklyPlan[]);

	/*
	Function: loadWeeklyExercisePlan()
	Date Created: 2/27/23
	Date Last Modified: 1/1/23
	Description: loads a week from the file into the weekly plan
	Input parameters: the file stream and the plan
	Returns: nothing
	Preconditions: none
	Postconditions: the information is read
	*/
	void loadWeeklyExercisePlan(std::fstream& fileStream, ExercisePlan weeklyPlan[]);

	//Display daily plans
	/*
	Function: displayDailyDietPlan()
	Date Created: 2/27/23
	Date Last Modified: 2/28/23
	Description: prints a day to the screen
	Input parameters: the plan
	Returns: nothing
	Preconditions: there must be data in the plan
	Postconditions: the information is printed
	*/
	void displayDailyDietPlan(DietPlan& rhs);

	/*
	Function: displayDailyExercisePlan()
	Date Created: 2/27/23
	Date Last Modified: 2/28/23
	Description: prints a day to the screen
	Input parameters: the plan
	Returns: nothing
	Preconditions: there must be data in the plan
	Postconditions: the information is printed
	*/
	void displayDailyExercisePlan(ExercisePlan& rhs);

	//display weekly plans
	/*
	Function: displayWeeklyDietPlan()
	Date Created: 2/27/23
	Date Last Modified: 2/28/23
	Description: prints a week to the screen
	Input parameters: the plan
	Returns: nothing
	Preconditions: there must be data in the plan
	Postconditions: the information is printed
	*/
	void displayWeeklyDietPlan(DietPlan rhs[]);

	/*
	Function: displayWeeklyExercisePlan()
	Date Created: 2/27/23
	Date Last Modified: 2/28/23
	Description: prints a week to the screen
	Input parameters: the plan
	Returns: nothing
	Preconditions: there must be data in the plan
	Postconditions: the information is printed
	*/
	void displayWeeklyExercisePlan(ExercisePlan rhs[]);

	//Storing daily plans
	/*
	Function: storeDailyDietPlan()
	Date Created: 2/27/23
	Date Last Modified: 2/28/23
	Description: prints a day to the file
	Input parameters: the plan and the file stream
	Returns: nothing
	Preconditions: there must be data in the plan
	Postconditions: the information is printed to the file
	*/
	void storeDailyDietPlan(std::fstream& fileStream, DietPlan& plan);

	/*
	Function: storeDailyExercisePlan()
	Date Created: 2/27/23
	Date Last Modified: 2/28/23
	Description: prints a day to the file
	Input parameters: the plan and the file stream
	Returns: nothing
	Preconditions: there must be data in the plan
	Postconditions: the information is printed to the file
	*/
	void storeDailyExercisePlan(std::fstream& fileStream, ExercisePlan& plan);

	//storing weekly plans
	/*
	Function: storeWeeklyDietPlan()
	Date Created: 2/27/23
	Date Last Modified: 2/28/23
	Description: prints a week to the file
	Input parameters: the plan and the file stream
	Returns: nothing
	Preconditions: there must be data in the plan
	Postconditions: the information is printed to the file
	*/
	void storeWeeklyDietPlan(std::fstream& fileStream, DietPlan plan[]);

	/*
	Function: storeWeeklyExercisePlan()
	Date Created: 2/27/23
	Date Last Modified: 2/28/23
	Description: prints a week to the file
	Input parameters: the plan and the file stream
	Returns: nothing
	Preconditions: there must be data in the plan
	Postconditions: the information is printed to the file
	*/
	void storeWeeklyExercisePlan(std::fstream& fileStream, ExercisePlan plan[]);

	//editing
	/*
	Function: editDailyDietPlan()
	Date Created: 2/27/23
	Date Last Modified: 2/28/23
	Description: allows the user to change a day in the plan
	Input parameters: the plan
	Returns: nothing
	Preconditions: there must be changeable data in the plan
	Postconditions: the information is changed
	*/
	void editDailyDietPlan(DietPlan plan[]);

	/*
	Function: editDailyExercisePlan()
	Date Created: 2/27/23
	Date Last Modified: 2/28/23
	Description: allows the user to change a day in the plan
	Input parameters: the plan
	Returns: nothing
	Preconditions: there must be changeable data in the plan
	Postconditions: the information is changed
	*/
	void editDailyExercisePlan(ExercisePlan plan[]);

	//menu
	int displayMenu();


private:
	DietPlan diet[7];
	ExercisePlan exercise[7];
	std::fstream dietStream;
	std::fstream exerciseStream;
};