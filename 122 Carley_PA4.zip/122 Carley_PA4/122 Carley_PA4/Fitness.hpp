/*
Name: Sarah Carley
Start date: 2/22/23
Date last edited: 2/26/23
Descrpition: This program will manage the user's exercise plan
*/

#pragma once

#include<iostream>
#include <fstream>
#include<string>