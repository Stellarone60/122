/*
Name: Sarah Carley
Start date: 3/29/23
Date last edited: 4/4/23
Descrpition: This program will manage class information
*/
#ifndef NODE_H
#define NODE_H

#include "Data.hpp"

template<class T>
class Node
{
public:
	/*
	Function: Node()
	Date Created: 3/29/23
	Date Last Modified: 3/29/23
	Description: constructs a node
	Input parameters: the new data
	Returns: nothing
	Preconditions: the data exists
	Postconditions: the node is constructed
	*/
	Node(T newData);

	/*
	Function: Node()
	Date Created: 4/4/23
	Date Last Modified: 4/4/23
	Description: destructs the node
	Input parameters: none
	Returns: nothing
	Preconditions: none
	Postconditions: the node is deconstructed
	*/
	~Node();

	Node(Node& copy);

	Node<T>& operator=(Node& rhs);

	/*
	Function: setNextPtr()
	Date Created: 3/29/23
	Date Last Modified: 3/29/23
	Description: sets the next pointer in a node
	Input parameters: the new pointer
	Returns: nothing
	Preconditions: the pointer exists
	Postconditions: the next node is updated
	*/
	void setNextPtr(Node<T>* newNext);

	/*
	Function: getNextPtr()
	Date Created: 4/4/23
	Date Last Modified: 4/4/23
	Description: returns the next pointer in the linked list
	Input parameters: none
	Returns: the pointer to the next node
	Preconditions: none
	Postconditions: the pointer is returned
	*/
	Node<T>* getNextPtr();

	/*
	Function: importNode()
	Date Created: 4/5/23
	Date Last Modified: 4/5/23
	Description: puts the node into the given file
	Input parameters: the file
	Returns: nothing
	Preconditions: the node must not be empty
	Postconditions: the node is put into the file
	*/
	void importNode(std::fstream& file);

	/*
	Function: getData()
	Date Created: 4/6/23
	Date Last Modified: 4/6/23
	Description: returns the data
	Input parameters: none
	Returns: the data
	Preconditions: none
	Postconditions: the data is returned
	*/
	T& getData();

private:
	T data;
	//T will become the Data class
	Node<T>* pNext;
};



#endif

/*
Function: Node()
Date Created: 3/29/23
Date Last Modified: 3/29/23
Description: constructs a node
Input parameters: the new data
Returns: nothing
Preconditions: the data exists
Postconditions: the node is constructed
*/
template<class T>
Node<T>::Node(T newData)
{
	this->pNext = nullptr;
	data = newData;//will need a copy constructor in the Data class for this
}

/*
Function: Node()
Date Created: 4/4/23
Date Last Modified: 4/4/23
Description: destructs the node
Input parameters: none
Returns: nothing
Preconditions: none
Postconditions: the node is deconstructed
*/
template<class T>
Node<T>::~Node()
{
}


template<class T>
Node<T>::Node(Node& copy)
{
	data = copy.data;
	pNext = copy.pNext;
}

template<class T>
inline Node<T>& Node<T>::operator=(Node& rhs)
{
	data = rhs.data;
	pNext = rhs.pNext;
	return *this;
	// TODO: insert return statement here
}

/*
Function: setNextPtr()
Date Created: 3/29/23
Date Last Modified: 3/29/23
Description: sets the next pointer in a node
Input parameters: the new pointer
Returns: nothing
Preconditions: the pointer exists
Postconditions: the next node is updated
*/
template<class T>
void Node<T>::setNextPtr(Node<T>* newNext)
{
	this->pNext = newNext;
}

/*
Function: getNextPtr()
Date Created: 4/4/23
Date Last Modified: 4/4/23
Description: returns the next pointer in the linked list
Input parameters: none
Returns: the pointer to the next node
Preconditions: none
Postconditions: the pointer is returned
*/
template<class T>
Node<T>* Node<T>::getNextPtr()
{
	return this->pNext;
}

/*
Function: importNode()
Date Created: 4/5/23
Date Last Modified: 4/5/23
Description: puts the node into the given file
Input parameters: the file
Returns: nothing
Preconditions: the node must not be empty
Postconditions: the node is put into the file
*/
template<class T>
void Node<T>::importNode(std::fstream& file)
{
	file << data;
}

/*
Function: getData()
Date Created: 4/6/23
Date Last Modified: 4/6/23
Description: returns the data
Input parameters: none
Returns: the data
Preconditions: none
Postconditions: the data is returned
*/
template<class T>
T& Node<T>::getData()
{
	return this->data;
}
