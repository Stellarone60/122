/*
Name: Sarah Carley
Start date: 3/29/23
Date last edited: 4/4/23
Descrpition: This program will manage class information
*/
#ifndef LIST_H
#define LIST_H

#include "Node.h"

template<class T>
class List
{
public:
	/*
	Function: List()
	Date Created: 3/29/23
	Date Last Modified: 3/29/23
	Description: constructs a list making it null
	Input parameters: none
	Returns: nothing
	Preconditions: none
	Postconditions: the list is constructed
	*/
	List();

	/*
	Function: ~List()
	Date Created: 4/4/23
	Date Last Modified: 4/4/23
	Description: destructs the list
	Input parameters: none
	Returns: nothing
	Preconditions: none
	Postconditions: the list is deconstructed
	*/
	~List();

	/*
	Function: insertAtFront()
	Date Created: 3/29/23
	Date Last Modified: 3/29/23
	Description: inserts a new node to the front of the list
	Input parameters: the new data
	Returns: nothing
	Preconditions: the data must exist
	Postconditions: the node is put at the front of the list
	*/
	void insertAtFront(const T newData);

	/*
	Function: getHeadPtr()
	Date Created: 3/29/23
	Date Last Modified: 3/29/23
	Description: gets the head pointer of the list
	Input parameters: none
	Returns: the head pointer
	Preconditions: none
	Postconditions: the head ptr is returned
	*/
	Node<T>* getHeadPtr() const;

	/*
	Function: setHeadPtr()
	Date Created: 3/29/23
	Date Last Modified: 3/29/23
	Description: sets the head pointer
	Input parameters: the new pointer
	Returns: nothing
	Preconditions: none
	Postconditions: the head ptr is set
	*/
	void setHeadPtr(Node<T>* const newHead);

	/*
	Function: clearList()
	Date Created: 4/4/23
	Date Last Modified: 4/4/23
	Description: clears the list
	Input parameters: none
	Returns: nothing
	Preconditions: none
	Postconditions: the list is cleared
	*/
	void clearList();

	/*
	Function: importRecords()
	Date Created: 4/5/23
	Date Last Modified: 4/5/23
	Description: puts the list into the given file
	Input parameters: the file
	Returns: nothing
	Preconditions: the list must not be empty
	Postconditions: the list is put into the file
	*/
	void importRecords(std::fstream& file);

	void markAbsences();

private:
	Node<T>* pHead;
};



#endif

/*
Function: List()
Date Created: 3/29/23
Date Last Modified: 3/29/23
Description: constructs a list making it null
Input parameters: none
Returns: nothing
Preconditions: none
Postconditions: the list is constructed
*/
template<class T>
inline List<T>::List()
{
	this->pHead = nullptr;
}

/*
Function: ~List()
Date Created: 4/4/23
Date Last Modified: 4/4/23
Description: destructs the list
Input parameters: none
Returns: nothing
Preconditions: none
Postconditions: the list is deconstructed
*/
template<class T>
List<T>::~List()
{
	std::cout << "called list deconstructor" << std::endl;
	/*while (this->pHead != nullptr)
	{
		Node<T> *temp = this->pHead;
		if (this->pHead->getNextPtr() != nullptr)
		{
			this->pHead = this->getHeadPtr()->getNextPtr();
		}
		delete temp;
	}*/
}

/*
Function: insertAtFront()
Date Created: 3/29/23
Date Last Modified: 3/29/23
Description: inserts a new node to the front of the list
Input parameters: the new data
Returns: nothing
Preconditions: the data must exist
Postconditions: the node is put at the front of the list
*/
template<class T>
void List<T>::insertAtFront(const T newData)
{
	Node<T>* memPtr = new Node<T>(newData);
	if (memPtr != nullptr)
	{
		//set next ptr to current head
		memPtr->setNextPtr(this->pHead);
		//change head ptr
		setHeadPtr(memPtr);
	}
}

/*
Function: getHeadPtr()
Date Created: 3/29/23
Date Last Modified: 3/29/23
Description: gets the head pointer of the list
Input parameters: none
Returns: the head pointer
Preconditions: none
Postconditions: the head ptr is returned
*/
template<class T>
Node<T>* List<T>::getHeadPtr() const
{
	return this->pHead;
}

/*
Function: setHeadPtr()
Date Created: 3/29/23
Date Last Modified: 3/29/23
Description: sets the head pointer
Input parameters: the new pointer
Returns: nothing
Preconditions: none
Postconditions: the head ptr is set
*/
template<class T>
void List<T>::setHeadPtr(Node<T>* const newHead)
{
	this->pHead = newHead;
}

/*
Function: clearList()
Date Created: 4/4/23
Date Last Modified: 4/4/23
Description: clears the list
Input parameters: none
Returns: nothing
Preconditions: none
Postconditions: the list is cleared
*/
template<class T>
void List<T>::clearList()
{
	while (this->pHead != nullptr)
	{
		Node<T>* temp = this->pHead;
		if (this->pHead->getNextPtr() != nullptr)
		{
			this->pHead = this->getHeadPtr()->getNextPtr();
		}
		delete temp;
	}
}

/*
Function: importRecords()
Date Created: 4/5/23
Date Last Modified: 4/5/23
Description: puts the list into the given file
Input parameters: the file
Returns: nothing
Preconditions: the list must not be empty
Postconditions: the list is put into the file
*/
template<class T>
void List<T>::importRecords(std::fstream& file)
{
	Node<T>* temp = this->pHead;
	while (temp != nullptr)
	{
		temp->importNode(file);
		if (temp->getNextPtr() != nullptr)
		{
			file << std::endl;
		}
		temp = temp->getNextPtr();
	}
}

template<class T>
inline void List<T>::markAbsences()
{
	Node<T>* temp = pHead;
	while (temp != nullptr)
	{
		temp->getData();
	}
}



