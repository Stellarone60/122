/*
Name: Sarah Carley
Start date: 3/29/23
Date last edited: 3/29/23
Descrpition: This program will manage class information
*/
#pragma once

#define _CRT_SECURE_NO_WARNINGS

#include<iostream>
#include<string>
#include<fstream>
#include<vector>
#include<chrono>
#include <ctime>
#include <iomanip>
#include <algorithm>
#include <sstream>

//how vector
class Stack
{
public:
	/*
	Function: Stack()
	Date Created: 3/30/23
	Date Last Modified: 3/30/23
	Description: constructs the stack
	Input parameters: none
	Returns: nothing
	Preconditions: none
	Postconditions: the stack is constructed
	*/
	Stack();

	/*
	Function: push()
	Date Created: 3/30/23
	Date Last Modified: 3/30/23
	Description: inserts a data value to the stack
	Input parameters: the tring to th absence
	Returns: nothing
	Preconditions: the string must exist
	Postconditions: the data is pushed onto the stack
	*/
	void push(std::string absent);

	/*
	Function: pop()
	Date Created: 3/30/23
	Date Last Modified: 3/30/23
	Description: gets rid of the "top" value
	Input parameters: none
	Returns: nothing
	Preconditions: the stack must not be empty
	Postconditions: the data is removed
	*/
	void pop();

	/*
	Function: peek()
	Date Created: 3/30/23
	Date Last Modified: 3/30/23
	Description: peeks at the "top" value
	Input parameters: none
	Returns: the "top" string
	Preconditions: the stack must not be empty
	Postconditions: the data is returned
	*/
	std::string peek();

	/*
	Function: printStack()
	Date Created: 4/5/23
	Date Last Modified: 4/5/23
	Description: prints the elements of the stack into the given file
	Input parameters: a file
	Returns: nothing
	Preconditions: none
	Postconditions: the data is written to the file
	*/
	void printStack(std::fstream& file);

	/*
	Function: getSize()
	Date Created: 4/4/23
	Date Last Modified: 4/5/23
	Description: gets the size of the stack
	Input parameters: none
	Returns: the size of the stack
	Preconditions: none
	Postconditions: the size is returned
	*/
	int getSize();

private:
	std::vector<std::string> stack;
};
