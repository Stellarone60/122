/*
Name: Sarah Carley
Start date: 3/30/23
Date last edited: 3/30/23
Descrpition: This program will manage class information
*/
#pragma once

#include "List.h"

class Menu
{
public:
	/*
	Function: Menu()
	Date Created: 3/30/23
	Date Last Modified: 3/30/23
	Description: constructs the menu
	Input parameters: none
	Returns: nothing
	Preconditions: none
	Postconditions: the menu is constructed
	*/
	Menu();

	/*
	Function: runProgram()
	Date Created: 4/4/23
	Date Last Modified: 4/4/23
	Description: runs the program
	Input parameters: none
	Returns: nothing
	Preconditions: none
	Postconditions: the program is run
	*/
	void runProgram();

private:
	List<Data> List;
};