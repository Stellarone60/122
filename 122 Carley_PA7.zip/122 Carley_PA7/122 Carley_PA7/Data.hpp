/*
Name: Sarah Carley
Start date: 3/29/23
Date last edited: 3/30/23
Descrpition: This program will manage class information
*/
#pragma once

#include "Stack.hpp"

class Data
{
public:
	/*
	Function: Data()
	Date Created: 3/30/23
	Date Last Modified: 3/30/23
	Description: constructs the data class
	Input parameters: The new data values (if one not passed in, given auto value)
	Returns: nothing
	Preconditions: none
	Postconditions: the data class is constructed
	*/
	Data(int newNum = 0, int ID = 0, std::string name = "-", std::string email = "-@-",
		std::string units = "AU", std::string program = "-", std::string level = "-", int numOfAbsences = 0)
	{
		this->studentNum = newNum;
		this->ID = ID;
		this->name = name;
		this->email = email;
		this->units = units;
		this->program = program;
		this->level = level;
		this->numOfAbsences = numOfAbsences;

		absences;
		//constructor for the vector???
	}

	/*
	Function: tokenize()
	Date Created: 3/30/23
	Date Last Modified: 3/30/23
	Description: splits the string like strtok
	Input parameters: the reference to the string
	Returns: a std::string to what was gotten
	Preconditions: the string must exist
	Postconditions: the tokenized value is returned
	*/
	std::string tokenize(std::string& line);

	/*
	Function: setValues()
	Date Created: 3/30/23
	Date Last Modified: 3/30/23
	Description: sets the value by calling tokenize multiple times
	Input parameters: the reference to the string
	Returns: nothing
	Preconditions: the string must exist
	Postconditions: the data values are set
	*/
	void setValues(std::string& line);

	/*
	Function: setMasterValues()
	Date Created: 4/6/23
	Date Last Modified: 4/6/23
	Description: sets the value by calling tokenize multiple times then getting the stack
	Input parameters: the reference to the string
	Returns: nothing
	Preconditions: the string must exist
	Postconditions: the data values are set
	*/
	void setMasterValues(std::string& line);

	/*
	Function: operator=()
	Date Created: 3/30/23
	Date Last Modified: 3/30/23
	Description: copies one set of data to another
	Input parameters: the reference to the data
	Returns: the new data
	Preconditions: the data must exist
	Postconditions: the data values are set
	*/
	Data& operator=(Data& rhs);

	
	/*
	Function: getStudentNum()
	Date Created: 4/4/23
	Date Last Modified: 4/4/23
	Description: gets the value
	Input parameters: none
	Returns: the value
	Preconditions: none
	Postconditions: the data value is returned
	*/
	int getStudentNum();

	/*
	Function: getID()
	Date Created: 4/4/23
	Date Last Modified: 4/4/23
	Description: gets the value
	Input parameters: none
	Returns: the value
	Preconditions: none
	Postconditions: the data value is returned
	*/
	int getID();

	/*
	Function: getName()
	Date Created: 4/4/23
	Date Last Modified: 4/4/23
	Description: gets the value
	Input parameters: none
	Returns: the value
	Preconditions: none
	Postconditions: the data value is returned
	*/
	std::string getName();

	/*
	Function: getEmail()
	Date Created: 4/4/23
	Date Last Modified: 4/4/23
	Description: gets the value
	Input parameters: none
	Returns: the value
	Preconditions: none
	Postconditions: the data value is returned
	*/
	std::string getEmail();

	/*
	Function: getUnits()
	Date Created: 4/4/23
	Date Last Modified: 4/4/23
	Description: gets the value
	Input parameters: none
	Returns: the value
	Preconditions: none
	Postconditions: the data value is returned
	*/
	std::string getUnits();

	/*
	Function: getProgram()
	Date Created: 4/4/23
	Date Last Modified: 4/4/23
	Description: gets the value
	Input parameters: none
	Returns: the value
	Preconditions: none
	Postconditions: the data value is returned
	*/
	std::string getProgram();

	/*
	Function: getLevel()
	Date Created: 4/4/23
	Date Last Modified: 4/4/23
	Description: gets the value
	Input parameters: none
	Returns: the value
	Preconditions: none
	Postconditions: the data value is returned
	*/
	std::string getLevel();

	/*
	Function: getNumAbsences()
	Date Created: 4/4/23
	Date Last Modified: 4/4/23
	Description: gets the value
	Input parameters: none
	Returns: the value
	Preconditions: none
	Postconditions: the data value is returned
	*/
	int getNumAbsences();

	/*
	Function: getAbsences()
	Date Created: 4/4/23
	Date Last Modified: 4/4/23
	Description: gets the value
	Input parameters: none
	Returns: the value
	Preconditions: none
	Postconditions: the data value is returned
	*/
	void printAbsences(std::fstream& file);

	/*
	Function: insertAbsences()
	Date Created: 4/6/23
	Date Last Modified: 4/6/23
	Description: checks if the student was absent, puts in when they were if it is true
	Input parameters: none
	Returns: nothing
	Preconditions: none
	Postconditions: the absence is put in (if student is absent)
	*/
	void insertAbsences();

	/*
	Function: generalReport()
	Date Created: 4/6/23
	Date Last Modified: 4/6/23
	Description: creates a general report for the students and prints to a file
	Input parameters: the file
	Returns: nothing
	Preconditions: none
	Postconditions: the report is printed
	*/
	void generalReport(std::fstream& file);

	/*
	Function: absenceReport()
	Date Created: 4/6/23
	Date Last Modified: 4/6/23
	Description: creates an absence report for the students and prints to a file
	Input parameters: the file, the number of absences the user wants it to be over
	Returns: nothing
	Preconditions: none
	Postconditions: the report is printed
	*/
	void absenceReport(std::fstream& file, int& absenceNum);

private:
	int studentNum;
	int ID;
	std::string name;
	std::string email;
	std::string units;
	std::string program;
	std::string level;


	int numOfAbsences;

	//idk how vectors work
	Stack absences;
};

/*
Function: operator()
Date Created: 4/4/23
Date Last Modified: 4/4/23
Description: prints the data to a file
Input parameters: the file stream and data type
Returns: the file stream
Preconditions: none
Postconditions: the data is printed to the file
*/
std::fstream& operator<<(std::fstream& lhs, Data& rhs);