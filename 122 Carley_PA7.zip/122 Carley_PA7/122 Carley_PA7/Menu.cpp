/*
Name: Sarah Carley
Start date: 4/5/23
Date last edited: 3/30/23
Descrpition: This program will manage class information
*/
#include "Menu.hpp"

/*
Function: Menu()
Date Created: 3/30/23
Date Last Modified: 3/30/23
Description: constructs the menu
Input parameters: none
Returns: nothing
Preconditions: none
Postconditions: the menu is constructed
*/
Menu::Menu()
{
	this->List;
}

/*
Function: runProgram()
Date Created: 4/4/23
Date Last Modified: 4/6/23
Description: runs the program
Input parameters: none
Returns: nothing
Preconditions: none
Postconditions: the program is run
*/
void Menu::runProgram()
{
	int choice = 0, choice2 = 0, absenceCusp = 0;
	//reading from the csv file
	Data temp;
	std::string dataStr = "";
	std::fstream dataFile;
	Node<Data>* tempNode = new Node<Data>(temp);
	std::cout << "What would you like to do?\n1: Import course list\n2: Load master list\n3: Store master list"
		<< "\n4: Mark Absences\n5: Generate Report\n6: Exit" << std::endl;
	std::cin >> choice;
	while (choice != 6)
	{
		switch (choice)
		{
		case 1:
			List.clearList();
			dataFile.open("classList.csv");
			std::getline(dataFile, dataStr);
			dataStr = "";
			while (dataFile)
			{
				if (dataStr == "");
				else
				{
					//apply data (strtok in a way but in the Data class)
					temp.setValues(dataStr);
					//insert to the list
					List.insertAtFront(temp);
				}
				//get string
				std::getline(dataFile, dataStr);
			}
			dataFile.close();


			std::cout << "What would you like to do?\n1: Import course list\n2: Load master list\n3: Store master list"
				<< "\n4: Mark Absences\n5: Generate Report\n6: Exit" << std::endl;
			std::cin >> choice;
			break;
		case 2:
			List.clearList();
			dataFile.open("MasterList.csv");
			while (dataFile)
			{
				if (dataStr == "");
				else
				{
					//apply data (strtok in a way but in the Data class)
					temp.setMasterValues(dataStr);
					//insert to the list
					List.insertAtFront(temp);
				}
				//get string
				std::getline(dataFile, dataStr);
			}
			dataFile.close();


			std::cout << "What would you like to do?\n1: Import course list\n2: Load master list\n3: Store master list"
				<< "\n4: Mark Absences\n5: Generate Report\n6: Exit" << std::endl;
			std::cin >> choice;
			break;
		case 3:
			dataFile.open("MasterList.csv");
			dataFile.clear();
			List.importRecords(dataFile);
			dataFile.close();
			std::cout << "Data imported successfully" << std::endl;

			std::cout << "What would you like to do?\n1: Import course list\n2: Load master list\n3: Store master list"
				<< "\n4: Mark Absences\n5: Generate Report\n6: Exit" << std::endl;
			std::cin >> choice;
			break;

		case 4:

			tempNode = List.getHeadPtr();
			while (tempNode != nullptr)
			{
				tempNode->getData().insertAbsences();
				tempNode = tempNode->getNextPtr();
			}

			system ("pause");
			system("cls");

			std::cout << "What would you like to do?\n1: Import course list\n2: Load master list\n3: Store master list"
				<< "\n4: Mark Absences\n5: Generate Report\n6: Exit" << std::endl;
			std::cin >> choice;
			break;
		case 5:
			std::cout << "Would you like to:\n1: Generate a report of all students\n2: Generate a report of absent students" << std::endl;
			std::cin >> choice2;
			if (choice2 == 1)
			{
				dataFile.open("GeneralReport.txt");

				tempNode = List.getHeadPtr();
				while (tempNode != nullptr)
				{
					tempNode->getData().generalReport(dataFile);
					tempNode = tempNode->getNextPtr();
				}
				
			}
			else
			{
				dataFile.open("AbsenceReport.txt");
				std::cout << "Looking for students with at least how many absences?" << std::endl;
				std::cin >> absenceCusp;
				tempNode = List.getHeadPtr();
				while (tempNode != nullptr)
				{
					tempNode->getData().absenceReport(dataFile, absenceCusp);
					tempNode = tempNode->getNextPtr();
				}
			}
			dataFile.close();


			std::cout << "What would you like to do?\n1: Import course list\n2: Load master list\n3: Store master list"
				<< "\n4: Mark Absences\n5: Generate Report\n6: Exit" << std::endl;
			std::cin >> choice;
			break;
		}
	}
}
