/*
Name: Sarah Carley
Start date: 3/29/23
Date last edited: 3/30/23
Descrpition: This program will manage class information
*/

#include "Data.hpp"

/*
Function: tokenize()
Date Created: 3/30/23
Date Last Modified: 3/30/23
Description: splits the string like strtok
Input parameters: the reference to the string
Returns: a std::string to what was gotten
Preconditions: the string must exist
Postconditions: the tokenized value is returned
*/
//much of the basis for thi code was gotten from
//https://www.geeksforgeeks.org/how-to-split-a-string-in-cc-python-and-java/
std::string Data::tokenize(std::string& line)
{
    std::string temp = "", newLine = "";
    int found = 0, i = 0, dec = 0;

    if (line[i] == '\"')
    {
        for (; i < (int)line.size() && found == 0; i++)
        {
            if (line[i] == '\"' && line[i + 1] == ',')
            {
                found = 1;
                i++;
                i++;
                dec = i;
                for (int j = 0; j < (int)line.size() - dec; j++, i++)
                {
                    newLine += line[i];
                }
                line = newLine;
            }
            else
            {
                temp += line[i];
            }
        }
        
    }
    else
    {
        for (; i < (int)line.size() && found == 0; i++)
        {
            // If cur char is not del, then append it to the cur "word", otherwise
              // you have completed the word, print it, and start a new word.

            if (line[i] != ',') {
                temp += line[i];



            }
            else
            {
                found = 1;
                i++;
                dec = i;
                for (int j = 0; j < (int)line.size() - dec; j++, i++)
                {
                    newLine += line[i];
                }
                line = newLine;
            }
        }
    }
    return temp;
}

/*
Function: setValues()
Date Created: 3/30/23
Date Last Modified: 3/30/23
Description: sets the value by calling tokenize multiple times
Input parameters: the reference to the string
Returns: nothing
Preconditions: the string must exist
Postconditions: the data values are set
*/
void Data::setValues(std::string& line)
{
    this->studentNum = std::stoi(tokenize(line));
    this->ID = std::stoi(tokenize(line));
    this->name = tokenize(line);
    this->email = tokenize(line);
    this->units = tokenize(line);
    this->program = tokenize(line);
    this->level = tokenize(line);
}

/*
Function: setMasterValues()
Date Created: 4/6/23
Date Last Modified: 4/6/23
Description: sets the value by calling tokenize multiple times then getting the stack
Input parameters: the reference to the string
Returns: nothing
Preconditions: the string must exist
Postconditions: the data values are set
*/
void Data::setMasterValues(std::string& line)
{
    int stack = 0, count = 0;
    this->studentNum = std::stoi(tokenize(line));
    this->ID = std::stoi(tokenize(line));
    this->name = tokenize(line);
    this->email = tokenize(line);
    this->units = tokenize(line);
    this->program = tokenize(line);
    this->level = tokenize(line);
    while (stack != 1)
    {
        absences.push(tokenize(line));
        count++;
        if (absences.peek() == "0" || count <= absences.getSize())
        {
            stack = 1;
        }
    }
}

/*
Function: operator=()
Date Created: 3/30/23
Date Last Modified: 3/30/23
Description: copies one set of data to another
Input parameters: the reference to the data
Returns: the new data
Preconditions: the data must exist
Postconditions: the data values are set
*/
Data& Data::operator=(Data& rhs)
{
    this->studentNum = rhs.studentNum;
    this->ID = rhs.ID;
    this->name = rhs.name;
    this->email = rhs.email;
    this->units = rhs.units;
    this->program = rhs.program;
    this->level = rhs.level;
    return *this;
}

/*
Function: getStudentNum()
Date Created: 4/4/23
Date Last Modified: 4/4/23
Description: gets the value
Input parameters: none
Returns: the value
Preconditions: none
Postconditions: the data value is returned
*/
int Data::getStudentNum()
{
    return this->studentNum;
}

/*
Function: getID()
Date Created: 4/4/23
Date Last Modified: 4/4/23
Description: gets the value
Input parameters: none
Returns: the value
Preconditions: none
Postconditions: the data value is returned
*/
int Data::getID()
{
    return this->ID;
}

/*
Function: getName()
Date Created: 4/4/23
Date Last Modified: 4/4/23
Description: gets the value
Input parameters: none
Returns: the value
Preconditions: none
Postconditions: the data value is returned
*/
std::string Data::getName()
{
    return this->name;
}

/*
Function: getEmail()
Date Created: 4/4/23
Date Last Modified: 4/4/23
Description: gets the value
Input parameters: none
Returns: the value
Preconditions: none
Postconditions: the data value is returned
*/
std::string Data::getEmail()
{
    return this->email;
}

/*
Function: getUnits()
Date Created: 4/4/23
Date Last Modified: 4/4/23
Description: gets the value
Input parameters: none
Returns: the value
Preconditions: none
Postconditions: the data value is returned
*/
std::string Data::getUnits()
{
    return this->units;
}

/*
Function: getProgram()
Date Created: 4/4/23
Date Last Modified: 4/4/23
Description: gets the value
Input parameters: none
Returns: the value
Preconditions: none
Postconditions: the data value is returned
*/
std::string Data::getProgram()
{
    return this->program;
}

/*
Function: getLevel()
Date Created: 4/4/23
Date Last Modified: 4/4/23
Description: gets the value
Input parameters: none
Returns: the value
Preconditions: none
Postconditions: the data value is returned
*/
std::string Data::getLevel()
{
    return this->level;
}

/*
Function: getNumAbsences()
Date Created: 4/4/23
Date Last Modified: 4/4/23
Description: gets the value
Input parameters: none
Returns: the value
Preconditions: none
Postconditions: the data value is returned
*/
int Data::getNumAbsences()
{
    return this->numOfAbsences;
}

/*
Function: getAbsences()
Date Created: 4/4/23
Date Last Modified: 4/4/23
Description: gets the value
Input parameters: none
Returns: the value
Preconditions: none
Postconditions: the data value is returned
*/
void Data::printAbsences(std::fstream& file)
{
    absences.printStack(file);
}

/*
Function: insertAbsences()
Date Created: 4/6/23
Date Last Modified: 4/6/23
Description: checks if the student was absent, puts in when they were if it is true
Input parameters: none
Returns: nothing
Preconditions: none
Postconditions: the absence is put in (if student is absent)
*/
void Data::insertAbsences()
{
    int choice = 0;
    std::cout << "Was " << this->name << " here today?\n1: yes\n2: No" << std::endl;
    std::cin >> choice;
    if (choice == 2)
    {
        //To turn the local time to a string, the code was gotte from user(s?) Max (and xuhdev?)
        //https://stackoverflow.com/questions/16357999/current-date-and-time-as-string
        auto t = std::time(nullptr);
        auto tm = *std::localtime(&t);

        std::ostringstream oss;
        oss << std::put_time(&tm, "%d-%m-%Y");
        auto str = oss.str();
        //end of that code chunk
        std::string string = "absent on: ";
        string += str;
        this->numOfAbsences++;


        absences.push(string);
    }
}

/*
Function: generalReport()
Date Created: 4/6/23
Date Last Modified: 4/6/23
Description: creates a general report for the students and prints to a file
Input parameters: the file
Returns: nothing
Preconditions: none
Postconditions: the report is printed
*/
void Data::generalReport(std::fstream& file)
{
    if (absences.getSize() != 0)
    {
        file << name << ": absent " << numOfAbsences << ". Most recent absence: " << absences.peek() << std::endl;
    }
    else
    {
        file << name << ": no absences" << std::endl;
    }
}

/*
Function: absenceReport()
Date Created: 4/6/23
Date Last Modified: 4/6/23
Description: creates an absence report for the students and prints to a file
Input parameters: the file, the number of absences the user wants it to be over
Returns: nothing
Preconditions: none
Postconditions: the report is printed
*/
void Data::absenceReport(std::fstream& file, int& absenceNum)
{
    if (absences.getSize() != 0)
    {
        if (numOfAbsences >= absenceNum)
        {
            file << name << std::endl;
        }
    }
}

/*
Function: operator()
Date Created: 4/4/23
Date Last Modified: 4/4/23
Description: prints the data to a file
Input parameters: the file stream and data type
Returns: the file stream
Preconditions: none
Postconditions: the data is printed to the file
*/
std::fstream& operator<<(std::fstream& lhs, Data& rhs)
{
    lhs << rhs.getStudentNum() << "," << rhs.getID() << "," << rhs.getName() << "\"," << rhs.getEmail()
        << "," << rhs.getUnits() << "," << rhs.getProgram() << "," << rhs.getLevel() << ","
        << rhs.getNumAbsences();
    //while loop for the stack???
    //Maybe make a print function solely for the stack
    rhs.printAbsences(lhs);
    return lhs;
}
