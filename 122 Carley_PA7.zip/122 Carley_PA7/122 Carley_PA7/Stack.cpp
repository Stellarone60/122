/*
Name: Sarah Carley
Start date: 3/29/23
Date last edited: 3/29/23
Descrpition: This program will manage class information
*/
#include "Stack.hpp"

/*
Function: Stack()
Date Created: 3/30/23
Date Last Modified: 3/30/23
Description: constructs the stack
Input parameters: none
Returns: nothing
Preconditions: none
Postconditions: the stack is constructed
*/
Stack::Stack()
{
	
}

/*
Function: push()
Date Created: 3/30/23
Date Last Modified: 3/30/23
Description: inserts a data value to the stack
Input parameters: the tring to th absence
Returns: nothing
Preconditions: the string must exist
Postconditions: the data is pushed onto the stack
*/
void Stack::push(std::string absent)
{
	stack.push_back(absent);
}

/*
Function: pop()
Date Created: 3/30/23
Date Last Modified: 3/30/23
Description: gets rid of the "top" value
Input parameters: none
Returns: nothing
Preconditions: the stack must not be empty
Postconditions: the data is removed
*/
void Stack::pop()
{
	stack.pop_back();
}

/*
Function: peek()
Date Created: 3/30/23
Date Last Modified: 3/30/23
Description: peeks at the "top" value
Input parameters: none
Returns: the "top" string
Preconditions: the stack must not be empty
Postconditions: the data is returned
*/
std::string Stack::peek()
{
	return stack.back();
}

/*
Function: printStack()
Date Created: 4/5/23
Date Last Modified: 4/5/23
Description: prints the elements of the stack into the given file
Input parameters: a file
Returns: nothing
Preconditions: none
Postconditions: the data is written to the file
*/
void Stack::printStack(std::fstream& file)
{
	if (stack.size() != 0)
	{
		//I know almost nothing about Vectors I am sorry, I used some code found here to figure
		//out how the heck to print  vector
		//https://thispointer.com/c-how-to-iterate-over-a-vector/
		for (int i = 0; i < this->getSize(); i++)
		{
			file << stack[i] << ",";
		}
	}
}
/*
Function: getSize()
Date Created: 4/4/23
Date Last Modified: 4/5/23
Description: gets the size of the stack
Input parameters: none
Returns: the size of the stack
Preconditions: none
Postconditions: the size is returned
*/
int Stack::getSize()
{
	return stack.size();
}
