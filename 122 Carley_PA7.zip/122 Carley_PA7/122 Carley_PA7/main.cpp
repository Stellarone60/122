/*
Name: Sarah Carley
Start date: 3/29/23
Date last edited: 4/4/23
Descrpition: This program will manage class information
*/

#include "Menu.hpp"

int main(void)
{
	//List<Data> list;

	//Data temp;
	//std::string dataStr = "";
	//std::fstream dataFile;
	//dataFile.open("classList.csv");
	//std::getline(dataFile, dataStr);
	//dataStr = "";
	//while (dataFile)
	//{
	//	if (dataStr == "");
	//	else
	//	{
	//		//apply data (strtok in a way but in the Data class)
	//		temp.setValues(dataStr);
	//		//insert to the list
	//		list.insertAtFront(temp);
	//	}
	//	//get string
	//	std::getline(dataFile, dataStr);
	//}
	//std::fstream newFile;
	//newFile.open("MasterList.csv");

	//Node<Data> node(temp);
	//Stack stack;
	//stack.printStack(newFile);
	//node.importNode(newFile);
	//list.importRecords(newFile);
	/*const std::chrono::time_point<std::chrono::system_clock>now = std::chrono::system_clock::now();
	const std::time_t t_c = std::chrono::system_clock::to_time_t(now);

	std::cout << "date: " << std::put_time(std::localtime(&t_c), "%D");*/

	Menu menu;
	menu.runProgram();

	return 0;
}